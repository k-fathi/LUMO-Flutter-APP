import { useState, useEffect } from "react";
import SplashScreen from "./components/SplashScreen";
import OnboardingScreen from "./components/OnboardingScreen";
import RoleSelectionScreen from "./components/RoleSelectionScreen";
import SignUpScreen from "./components/SignUpScreen";
import SignInScreen from "./components/SignInScreen";
import ProfileScreen from "./components/ProfileScreen";
import EditProfileScreen from "./components/EditProfileScreen";
import UserProfileScreen from "./components/UserProfileScreen";
import FollowersScreen from "./components/FollowersScreen";
import FollowingScreen from "./components/FollowingScreen";
import MyPatientsScreen from "./components/MyPatientsScreen";
import PatientRequestScreen from "./components/PatientRequestScreen";
import PatientDetailsScreen from "./components/PatientDetailsScreen";
import ForgotPasswordScreen from "./components/ForgotPasswordScreen";
import VerificationCodeScreen from "./components/VerificationCodeScreen";
import ResetPasswordScreen from "./components/ResetPasswordScreen";
import AnalysisScreen from "./components/AnalysisScreen";
import CommunityScreen from "./components/CommunityScreen";
import ChatScreen from "./components/ChatScreen";
import ChatListScreen from "./components/ChatListScreen";
import ChatbotScreen from "./components/ChatbotScreen";
import CreatePostScreen from "./components/CreatePostScreen";
import EditPostScreen from "./components/EditPostScreen";
import CommentsScreen from "./components/CommentsScreen";
import SearchScreen from "./components/SearchScreen";
import BottomNav from "./components/BottomNav";

type AppState =
  | "splash"
  | "onboarding"
  | "roleselection"
  | "signup"
  | "signin"
  | "main"
  | "createpost"
  | "editpost"
  | "comments"
  | "search"
  | "editprofile"
  | "userprofile"
  | "followers"
  | "following"
  | "mypatients"
  | "patientdetails"
  | "patientrequest"
  | "forgotpassword"
  | "verificationcode"
  | "resetpassword"
  | "newchat";

export default function App() {
  const [appState, setAppState] = useState<AppState>("splash");
  const [onboardingStep, setOnboardingStep] = useState(0);
  const [activeTab, setActiveTab] = useState("community");
  const [selectedRole, setSelectedRole] = useState<
    "parent" | "doctor"
  >("parent");
  const [editingPostId, setEditingPostId] = useState<
    number | null
  >(null);
  const [editingPostContent, setEditingPostContent] =
    useState("");
  const [selectedPost, setSelectedPost] = useState<{
    id: number;
    author: string;
    content: string;
  } | null>(null);
  const [selectedPatient, setSelectedPatient] = useState<{
    id: number;
    name: string;
    age: number;
    avatar: string;
  } | null>(null);
  const [forgotPasswordEmail, setForgotPasswordEmail] =
    useState("");
  const [selectedChatId, setSelectedChatId] = useState<
    number | null
  >(null);

  // Simulate splash screen timeout
  useEffect(() => {
    if (appState === "splash") {
      const timer = setTimeout(() => {
        setAppState("onboarding");
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [appState]);

  const handleOnboardingNext = () => {
    if (onboardingStep < 2) {
      setOnboardingStep(onboardingStep + 1);
    } else {
      setAppState("roleselection");
    }
  };

  const handleOnboardingSkip = () => {
    setAppState("roleselection");
  };

  const handleRoleSelection = (role: "parent" | "doctor") => {
    setSelectedRole(role);
    setAppState("signup");
  };

  const handleSignUp = () => {
    setAppState("main");
  };

  const handleSignIn = () => {
    setAppState("main");
  };

  const handleSignUpClick = () => {
    setAppState("signup");
  };

  const handleSignInClick = () => {
    setAppState("signin");
  };

  const handleCreatePost = () => {
    setAppState("createpost");
  };

  const handleBackFromCreatePost = () => {
    setAppState("main");
    setActiveTab("community");
  };

  const handlePublishPost = () => {
    // Here you would normally save the post
    setAppState("main");
    setActiveTab("community");
  };

  const handleEditPost = (postId: number, content: string) => {
    setEditingPostId(postId);
    setEditingPostContent(content);
    setAppState("editpost");
  };

  const handleSaveEditedPost = () => {
    // Here you would normally update the post
    setAppState("main");
    setActiveTab("community");
    setEditingPostId(null);
    setEditingPostContent("");
  };

  const handleDeletePost = (postId: number) => {
    // Here you would normally delete the post
    // For now, just show confirmation (in a real app, use a confirmation dialog)
    console.log("Delete post:", postId);
  };

  const handleViewComments = (
    postId: number,
    author: string,
    content: string,
  ) => {
    setSelectedPost({ id: postId, author, content });
    setAppState("comments");
  };

  const handleBackFromComments = () => {
    setAppState("main");
    setActiveTab("community");
    setSelectedPost(null);
  };

  const handleSearch = () => {
    setAppState("search");
  };

  const handleBackFromSearch = () => {
    setAppState("main");
    setActiveTab("community");
  };

  const handleBackFromEditPost = () => {
    setAppState("main");
    setActiveTab("community");
    setEditingPostId(null);
    setEditingPostContent("");
  };

  const handleEditProfile = () => {
    setAppState("editprofile");
  };

  const handleBackFromEditProfile = () => {
    setAppState("main");
    setActiveTab("profile");
  };

  const handleViewUserProfile = () => {
    setAppState("userprofile");
  };

  const handleBackFromUserProfile = () => {
    setAppState("main");
    setActiveTab("community");
  };

  const handleChatFromUserProfile = () => {
    setAppState("main");
    setActiveTab("chat");
    setSelectedChatId(null);
  };

  const handleViewFollowers = () => {
    setAppState("followers");
  };

  const handleBackFromFollowers = () => {
    setAppState("main");
    setActiveTab("profile");
  };

  const handleViewFollowing = () => {
    setAppState("following");
  };

  const handleBackFromFollowing = () => {
    setAppState("main");
    setActiveTab("profile");
  };

  const handleViewProfileFromChat = () => {
    setAppState("userprofile");
  };

  const handleChatClick = (chatId: number) => {
    setSelectedChatId(chatId);
  };

  const handleBackFromChat = () => {
    setSelectedChatId(null);
  };

  const handleViewPatients = () => {
    setAppState("mypatients");
  };

  const handleBackFromPatients = () => {
    setAppState("main");
    setActiveTab("profile");
  };

  const handleViewPatientRequest = () => {
    setAppState("patientrequest");
  };

  const handleBackFromPatientRequest = () => {
    setAppState("main");
    setActiveTab("profile");
  };

  const handleRequestSent = () => {
    setAppState("main");
    setActiveTab("profile");
  };

  const handleForgotPassword = () => {
    setAppState("forgotpassword");
  };

  const handleBackFromForgotPassword = () => {
    setAppState("signin");
  };

  const handleSendVerificationCode = (email: string) => {
    setForgotPasswordEmail(email);
    setAppState("verificationcode");
  };

  const handleBackFromVerificationCode = () => {
    setAppState("forgotpassword");
  };

  const handleVerificationSuccess = () => {
    setAppState("resetpassword");
  };

  const handleBackFromResetPassword = () => {
    setAppState("verificationcode");
  };

  const handlePasswordReset = () => {
    setAppState("signin");
    setForgotPasswordEmail("");
  };

  const handlePatientClick = (patient: {
    id: number;
    name: string;
    age: number;
    avatar: string;
  }) => {
    setSelectedPatient(patient);
    setAppState("patientdetails");
  };

  const handleBackFromPatientDetails = () => {
    setAppState("main");
    setActiveTab("mypatients");
    setSelectedPatient(null);
  };

  const handleSignOut = () => {
    // Reset to sign in screen
    setAppState("signin");
    setActiveTab("community");
    setSelectedChatId(null);
  };

  const handleDeleteAccount = () => {
    // In a real app, this would make an API call to delete the account
    // For now, just redirect to role selection screen
    setAppState("roleselection");
    setActiveTab("community");
    setSelectedChatId(null);
  };

  const handleNewChat = () => {
    setAppState("newchat");
  };

  const handleBackFromNewChat = () => {
    setAppState("main");
    setActiveTab("chat");
  };

  const handleStartChat = (followerId: number) => {
    // In a real app, this would create a new chat with the selected follower
    // For now, just navigate back to chat list
    setAppState("main");
    setActiveTab("chat");
    setSelectedChatId(null);
  };

  // Render based on app state
  if (appState === "splash") {
    return <SplashScreen />;
  }

  if (appState === "onboarding") {
    return (
      <OnboardingScreen
        step={onboardingStep}
        onNext={handleOnboardingNext}
        onSkip={handleOnboardingSkip}
      />
    );
  }

  if (appState === "roleselection") {
    return (
      <RoleSelectionScreen onSelectRole={handleRoleSelection} />
    );
  }

  if (appState === "signup") {
    return (
      <SignUpScreen
        role={selectedRole}
        onSignUp={handleSignUp}
        onSignInClick={handleSignInClick}
      />
    );
  }

  if (appState === "signin") {
    return (
      <SignInScreen
        onSignIn={handleSignIn}
        onSignUpClick={handleSignUpClick}
        onForgotPassword={handleForgotPassword}
      />
    );
  }

  if (appState === "forgotpassword") {
    return (
      <ForgotPasswordScreen
        onBack={handleBackFromForgotPassword}
        onSendCode={handleSendVerificationCode}
      />
    );
  }

  if (appState === "verificationcode") {
    return (
      <VerificationCodeScreen
        onBack={handleBackFromVerificationCode}
        onVerify={handleVerificationSuccess}
        email={forgotPasswordEmail}
      />
    );
  }

  if (appState === "resetpassword") {
    return (
      <ResetPasswordScreen
        onBack={handleBackFromResetPassword}
        onReset={handlePasswordReset}
      />
    );
  }

  if (appState === "createpost") {
    return (
      <CreatePostScreen
        onBack={handleBackFromCreatePost}
        onPublish={handlePublishPost}
      />
    );
  }

  if (appState === "editpost") {
    return (
      <EditPostScreen
        onBack={handleBackFromEditPost}
        onSave={handleSaveEditedPost}
        initialContent={editingPostContent}
      />
    );
  }

  if (appState === "comments" && selectedPost) {
    return (
      <CommentsScreen
        onBack={handleBackFromComments}
        postAuthor={selectedPost.author}
        postContent={selectedPost.content}
      />
    );
  }

  if (appState === "search") {
    return <SearchScreen onBack={handleBackFromSearch} />;
  }

  if (appState === "editprofile") {
    return (
      <EditProfileScreen
        onBack={handleBackFromEditProfile}
        onSignOut={handleSignOut}
        onDeleteAccount={handleDeleteAccount}
      />
    );
  }

  if (appState === "userprofile") {
    return (
      <UserProfileScreen
        onBack={handleBackFromUserProfile}
        onChat={handleChatFromUserProfile}
        onViewFollowers={handleViewFollowers}
        onViewFollowing={handleViewFollowing}
      />
    );
  }

  if (appState === "followers") {
    return (
      <FollowersScreen
        onBack={handleBackFromFollowers}
        onViewProfile={handleViewUserProfile}
      />
    );
  }

  if (appState === "following") {
    return (
      <FollowingScreen
        onBack={handleBackFromFollowing}
        onViewProfile={handleViewUserProfile}
      />
    );
  }

  if (appState === "mypatients") {
    return (
      <MyPatientsScreen
        onBack={handleBackFromPatients}
        onPatientClick={handlePatientClick}
      />
    );
  }

  if (appState === "patientdetails" && selectedPatient) {
    return (
      <PatientDetailsScreen
        onBack={handleBackFromPatientDetails}
        patientName={selectedPatient.name}
        patientAge={selectedPatient.age}
        patientAvatar={selectedPatient.avatar}
      />
    );
  }

  if (appState === "patientrequest") {
    return (
      <PatientRequestScreen
        onBack={handleBackFromPatientRequest}
        onRequestSent={handleRequestSent}
      />
    );
  }

  if (appState === "newchat") {
    return (
      <FollowersScreen
        onBack={handleBackFromNewChat}
        onViewProfile={handleViewUserProfile}
        onStartChat={handleStartChat}
        showChatOption={true}
      />
    );
  }

  // Main app with bottom navigation
  return (
    <div className="max-w-md mx-auto bg-white min-h-screen relative">
      {/* Main Content */}
      <div className="pb-20">
        {activeTab === "community" && (
          <CommunityScreen
            onCreatePost={handleCreatePost}
            onEditPost={handleEditPost}
            onDeletePost={handleDeletePost}
            onViewComments={handleViewComments}
            onSearch={handleSearch}
          />
        )}
        {activeTab === "analysis" && <AnalysisScreen />}
        {activeTab === "mypatients" && (
          <MyPatientsScreen
            onBack={() => setActiveTab("profile")}
            onPatientClick={handlePatientClick}
          />
        )}
        {activeTab === "chat" &&
          (selectedChatId ? (
            <ChatScreen
              onViewProfile={handleViewProfileFromChat}
              onBack={handleBackFromChat}
            />
          ) : (
            <ChatListScreen
              onChatClick={handleChatClick}
              onNewChat={handleNewChat}
            />
          ))}
        {activeTab === "chatbot" && <ChatbotScreen />}
        {activeTab === "profile" && (
          <ProfileScreen
            role={selectedRole}
            onEditProfile={handleEditProfile}
            onViewFollowers={handleViewFollowers}
            onViewFollowing={handleViewFollowing}
            onViewComments={handleViewComments}
            onViewPatients={handleViewPatients}
            onPatientRequest={handleViewPatientRequest}
          />
        )}
      </div>

      {/* Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        role={selectedRole}
      />

      {/* Quick Access to All Screens (for demo purposes) */}
      <div className="fixed top-4 left-4 z-50" dir="rtl">
        <details className="bg-white rounded-2xl shadow-lg border border-[#E3F2FD]">
          <summary className="px-4 py-2 cursor-pointer text-sm text-[#2196F3] list-none">
            📱 الشاشات
          </summary>
          <div className="px-4 py-2 space-y-2 max-h-96 overflow-y-auto">
            <button
              onClick={() => setAppState("splash")}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              شاشة البداية
            </button>
            <button
              onClick={() => {
                setAppState("onboarding");
                setOnboardingStep(0);
              }}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              التعريف
            </button>
            <button
              onClick={() => setAppState("roleselection")}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              اختيار الدور
            </button>
            <button
              onClick={() => setAppState("signup")}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              التسجيل
            </button>
            <button
              onClick={() => setAppState("signin")}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              تسجيل الدخول
            </button>
            <hr className="my-2 border-[#E3F2FD]" />
            <button
              onClick={() => {
                setAppState("main");
                setActiveTab("community");
              }}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              المجتمع (الرئيسية)
            </button>
            <button
              onClick={() => setAppState("createpost")}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              إنشاء منشور
            </button>
            <button
              onClick={() => setAppState("search")}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              بحث المستخدمين
            </button>
            <button
              onClick={() => {
                setAppState("main");
                setActiveTab("analysis");
              }}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              التحليل
            </button>
            <button
              onClick={() => {
                setAppState("main");
                setActiveTab("chat");
              }}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              الدردشة (الطبيب)
            </button>
            <button
              onClick={() => {
                setAppState("main");
                setActiveTab("chatbot");
              }}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              المساعد الذكي
            </button>
            <button
              onClick={() => {
                setAppState("main");
                setActiveTab("profile");
              }}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              ملفي الشخصي
            </button>
            <button
              onClick={() => setAppState("editprofile")}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              تعديل الملف
            </button>
            <button
              onClick={() => setAppState("userprofile")}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              ملف المستخدم
            </button>
            <button
              onClick={() => setAppState("followers")}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              المتابعون
            </button>
            <button
              onClick={() => setAppState("following")}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              المتابَعون
            </button>
            <button
              onClick={() => setAppState("mypatients")}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              مرضاي (طبيب)
            </button>
            <button
              onClick={() => {
                setSelectedPatient({
                  id: 1,
                  name: "أحمد محمد",
                  age: 8,
                  avatar:
                    "https://api.dicebear.com/7.x/avataaars/svg?seed=ahmed",
                });
                setAppState("patientdetails");
              }}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              تفاصيل المريض
            </button>
            <button
              onClick={() => setAppState("patientrequest")}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              طلب انضمام (مريض)
            </button>
            <hr className="my-2 border-[#E3F2FD]" />
            <button
              onClick={() => setAppState("forgotpassword")}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              نسيت كلمة المرور
            </button>
            <button
              onClick={() => {
                setForgotPasswordEmail("test@example.com");
                setAppState("verificationcode");
              }}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              رمز التحقق
            </button>
            <button
              onClick={() => setAppState("resetpassword")}
              className="block w-full text-right text-sm text-[#64748b] hover:text-[#2196F3] py-1"
            >
              إعادة تعيين كلمة المرور
            </button>
          </div>
        </details>
      </div>
    </div>
  );
}