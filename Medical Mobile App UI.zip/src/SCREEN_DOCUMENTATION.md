# LUMO Medical App - Complete Screen Documentation

## Table of Contents
1. [Authentication & Onboarding Screens](#authentication--onboarding-screens)
2. [Main App Screens (Bottom Navigation)](#main-app-screens-bottom-navigation)
3. [Social Features](#social-features)
4. [Patient Management (Doctor-Only)](#patient-management-doctor-only)
5. [Profile & Settings](#profile--settings)
6. [Password Recovery](#password-recovery)

---

## Authentication & Onboarding Screens

### 1. Splash Screen (`SplashScreen.tsx`)

**Purpose:**
- Initial loading screen displayed when the app launches
- Shows LUMO robot mascot with animated floating effect
- Auto-transitions to onboarding after 3 seconds

**UI Elements:**
- **LUMO Robot Image**: Animated mascot with floating animation (moves up and down)
- **Gradient Background**: Light Blue (#E3F2FD) to white gradient

**Inputs/Buttons:**
None (auto-navigates)

**User Flow:**
1. App launches → Splash screen appears
2. After 3 seconds → Automatically navigates to Onboarding Screen
3. During display → Robot logo animates with floating effect

---

### 2. Onboarding Screen (`OnboardingScreen.tsx`)

**Purpose:**
- Introduces new users to the app's key features
- Three-step introduction with swipeable content
- Educates users about health tracking, AI consultations, and doctor connections

**UI Elements:**
- **Skip Button** (top right): Skips onboarding and goes directly to Role Selection
- **Feature Image**: Large rounded image showcasing the feature
- **Title**: Feature headline in Arabic
- **Subtitle**: Detailed feature description in Arabic
- **Dot Indicators**: Shows current step (3 dots, current one is elongated and blue)
- **Next/Start Button**: Advances to next step or starts the app

**Onboarding Content:**
- **Step 1**: Health Tracking - "تتبع صحتك"
- **Step 2**: AI Medical Consultations - "استشارات طبية بالذكاء الاصطناعي"
- **Step 3**: Connect with Doctors - "تواصل مع الأطباء"

**Buttons:**
- **Skip Button**: Bypasses onboarding, goes to Role Selection
- **Next Button**: Advances to next onboarding step (Steps 1-2)
- **Start Button** ("ابدأ الآن"): Appears on final step, navigates to Role Selection

**User Flow:**
1. User lands on Onboarding → Views Step 1
2. User taps "Skip" → Goes to Role Selection Screen
   OR
3. User taps "Next" → Advances to Step 2 → Taps "Next" → Advances to Step 3
4. User taps "ابدأ الآن" (Start Now) → Goes to Role Selection Screen

---

### 3. Role Selection Screen (`RoleSelectionScreen.tsx`)

**Purpose:**
- Allows users to choose their role in the app
- Determines which features and UI elements are available
- Gateway to role-specific sign-up flows

**UI Elements:**
- **LUMO Robot Image**: Brand mascot at the top
- **Welcome Title**: "مرحباً بك في لومو" (Welcome to LUMO)
- **Instructions**: "يرجى اختيار دورك للمتابعة" (Please choose your role to continue)
- **Two Role Buttons**:
  - Parent/User Button: User icon + "أنا مستخدم"
  - Doctor Button: Stethoscope icon + "أنا طبيب"
- **Footer Text**: "صحتك، أولويتنا." (Your health, our priority)

**Buttons:**
- **"أنا مستخدم" (I'm a User/Parent)**: Selects parent role, navigates to Sign Up as Parent
- **"أنا طبيب" (I'm a Doctor)**: Selects doctor role, navigates to Sign Up as Doctor

**User Flow:**
1. User arrives from Onboarding → Views role selection options
2. User taps "أنا مستخدم" → Sets role to Parent → Goes to Sign Up Screen (Parent version)
   OR
3. User taps "أنا طبيب" → Sets role to Doctor → Goes to Sign Up Screen (Doctor version)

---

### 4. Sign Up Screen (`SignUpScreen.tsx`)

**Purpose:**
- Creates new user account for the selected role
- Collects role-specific information
- Different fields appear based on Parent vs. Doctor role

**UI Elements:**
- **Header Icon**: Role-specific icon (Baby for Parent, Stethoscope for Doctor)
- **Title**: "إنشاء حساب" (Create Account)
- **Role Indicator**: "التسجيل كطبيب" or "التسجيل كمستخدم"
- **Form Fields** (see inputs below)
- **Create Account Button**: Primary CTA button
- **Sign In Link**: "لديك حساب بالفعل؟ تسجيل الدخول"

**Inputs:**
**Common Fields (Both Roles):**
- **Full Name** (User icon): Text input for full name
- **Email** (Mail icon): Email input
- **Mobile Number** (Phone icon): Phone number input
- **Password** (Lock icon): Password input
- **Confirm Password** (Lock icon): Password confirmation input

**Doctor-Only Fields:**
- **Doctor ID** (CreditCard icon): Doctor license/registration number
- **Clinic Location** (MapPin icon): Clinic address

**Parent-Only Fields:**
- **Child Name** (Baby icon): Child's name
- **Child Age** (Calendar icon): Child's age (number input)

**Buttons:**
- **"إنشاء حساب" (Create Account)**: Submits form, creates account, navigates to Main App
- **"تسجيل الدخول" (Sign In)** link: Navigates to Sign In Screen

**User Flow:**
1. User arrives from Role Selection → Views appropriate sign-up form
2. User fills in all required fields
3. User taps "إنشاء حساب" → Account created → Navigates to Main App (Community Screen)
   OR
4. User taps "تسجيل الدخول" link → Navigates to Sign In Screen

---

### 5. Sign In Screen (`SignInScreen.tsx`)

**Purpose:**
- Authenticates existing users
- Provides access to forgot password flow
- Gateway to main application

**UI Elements:**
- **Heart Icon**: App brand icon in gradient circle
- **Title**: "مرحباً بعودتك" (Welcome Back)
- **Subtitle**: "سجل الدخول لمتابعة رحلتك الصحية"
- **Form Fields** (see inputs below)
- **Forgot Password Link**
- **Sign In Button**
- **Sign Up Link**

**Inputs:**
- **Email** (Mail icon): Email address input
- **Password** (Lock icon): Password input

**Buttons/Links:**
- **"نسيت كلمة المرور؟" (Forgot Password?)**: Navigates to Forgot Password Screen
- **"تسجيل الدخول" (Sign In)**: Authenticates user, navigates to Main App
- **"إنشاء حساب" (Create Account)** link: Navigates to Role Selection Screen

**User Flow:**
1. User enters email and password
2. User taps "تسجيل الدخول" → Authenticated → Navigates to Main App (Community Screen)
   OR
3. User taps "نسيت كلمة المرور؟" → Navigates to Forgot Password Screen
   OR
4. User taps "إنشاء حساب" link → Navigates to Role Selection Screen

---

## Main App Screens (Bottom Navigation)

### 6. Community Screen (`CommunityScreen.tsx`)

**Purpose:**
- Main social feed showing posts from doctors and parents
- Allows users to create posts, interact with content, and search users
- Central hub for community engagement

**UI Elements:**
- **Header**: "المجتمع" title + Search button
- **Quick Post Card**: Shows user avatar + "بماذا تفكر؟" placeholder + Plus button
- **Post Feed**: Scrollable list of community posts
- **Each Post Contains**:
  - User avatar and name
  - Role badge (طبيب قلب, مستخدم, etc.)
  - Timestamp
  - Post content text
  - Like count + icon
  - Comment count + icon
  - Three-dot menu (Edit/Delete options)

**Buttons:**
- **Search Icon** (header): Opens Search Screen
- **Quick Post Card**: Taps anywhere opens Create Post Screen
- **Plus Button**: Opens Create Post Screen
- **Three-Dot Menu** on posts: Opens dropdown with:
  - "تعديل المنشور" (Edit Post) → Opens Edit Post Screen
  - "حذف المنشور" (Delete Post) → Deletes post
- **Heart Icon** (on each post): Likes the post
- **Comment Icon** (on each post): Opens Comments Screen for that post

**User Flow:**
1. User views community feed
2. User taps Quick Post Card or Plus button → Creates new post
3. User taps Three-Dot menu on own post → Edits or deletes post
4. User taps Comment icon → Views/adds comments on post
5. User taps Search icon → Searches for other users
6. User taps Like icon → Likes/unlikes post

---

### 7. Analysis Screen (`AnalysisScreen.tsx`) - **Parent Only**

**Purpose:**
- Displays emotional analysis data for the child
- Shows historical analysis results with pie charts
- Tracks child's emotional patterns over time

**UI Elements:**
- **Header**: "التحليل" (Analysis) title + right chevron
- **Analysis Cards**: List of historical analysis results
- **Each Card Contains**:
  - Date/time stamp
  - Activity title "الألغاز" (Puzzles)
  - Donut chart showing emotion distribution
  - Checklist of emotions:
    - محايد (Neutral)
    - حزين (Sad)
    - خائف (Scared)
    - غاضب (Angry)
    - سعيد (Happy)

**Buttons:**
- **Right Chevron** (header): Navigation action (currently non-functional)

**User Flow:**
1. Parent views analysis screen
2. Parent scrolls through historical analysis cards
3. Parent reviews emotion distribution via pie charts and checklists

---

### 8. My Patients Screen (`MyPatientsScreen.tsx`) - **Doctor Only**

**Purpose:**
- Doctor's patient management dashboard
- Displays list of all patients
- Generates invitation codes for new patients
- Manages patient join requests

**UI Elements:**
- **Header**: "مرضاي" (My Patients) title + back button
- **"كود جديد" Button**: Generates new patient invitation code
- **Total Patients Card**: Shows total count in gradient card with user icon
- **Pending Requests Section**: "طلبات الانضمام" (Join Requests)
  - Shows pending patient requests with Accept/Reject buttons
- **Patient List**: "قائمة المرضى" (Patient List)
  - Each patient card shows: avatar, name, age, last visit

**Buttons:**
- **Back Button** (header): Returns to Profile Screen
- **"كود جديد" (New Code)**: Opens dialog with:
  - 6-character alphanumeric code
  - "نسخ الكود" (Copy Code) button
  - "إغلاق" (Close) button
  - Code valid for 24 hours
- **Check Icon** (on pending requests): Accepts patient request
- **X Icon** (on pending requests): Rejects patient request
- **Patient Card**: Taps on patient → Opens Patient Details Screen

**User Flow:**
1. Doctor views patient dashboard
2. Doctor taps "كود جديد" → Generates code → Shares with patient
3. Doctor reviews pending requests → Accepts or rejects
4. Doctor taps on patient card → Views patient details and analysis

---

### 9. Chat List Screen (`ChatListScreen.tsx`)

**Purpose:**
- Displays all active conversations
- Shows recent messages and online status
- Provides access to start new conversations

**UI Elements:**
- **Header**: "الدردشة" (Chat) title with gradient background
- **Search Bar**: Searches conversations
- **Chat List**: Recent conversations showing:
  - User avatar with online indicator (green dot)
  - User name
  - Last message preview
  - Timestamp
  - Unread count badge (if unread messages exist)
- **Floating Action Button**: Plus icon to start new chat
- **Empty State**: Shows when no chats exist

**Buttons:**
- **Search Bar**: Searches through conversations (currently non-functional)
- **Chat Item**: Taps anywhere → Opens Chat Screen with that user
- **Plus Button** (floating): Opens Followers Screen to select someone to chat with

**User Flow:**
1. User views chat list
2. User taps on existing chat → Opens Chat Screen
   OR
3. User taps Plus button → Selects follower from list → Opens Chat Screen
4. User sees unread count badges on unread conversations

---

### 10. Chat Screen (`ChatScreen.tsx`)

**Purpose:**
- One-on-one conversation interface
- Send/receive messages with doctors or parents
- Access to voice calls and user profile

**UI Elements:**
- **Header** with:
  - Back button
  - User avatar (tappable)
  - User name (tappable)
  - Online status "نشط الآن" (Active Now)
  - Phone icon for calls
  - Three-dot menu (View Profile, Block User)
- **Message Area**: Chat bubbles with timestamps
  - User messages: Blue gradient, right-aligned
  - Doctor messages: White, left-aligned
- **Input Bar**:
  - Attachment button (Paperclip icon)
  - Message text input
  - Send button (gradient circle)

**Buttons:**
- **Back Button**: Returns to Chat List
- **Avatar/Name**: Opens User Profile Screen
- **Phone Icon**: Initiates voice call (currently non-functional)
- **Three-Dot Menu**: Opens dropdown with:
  - "عرض الملف الشخصي" (View Profile) → Opens User Profile Screen
  - "حظر المستخدم" (Block User) → Blocks user (currently non-functional)
- **Paperclip Icon**: Attaches files (currently non-functional)
- **Send Button**: Sends message

**User Flow:**
1. User types message in input field
2. User taps Send → Message appears in chat
3. User taps on doctor avatar/name → Views doctor profile
4. User taps Phone icon → Initiates call
5. User taps Back → Returns to Chat List

---

### 11. Chatbot Screen (`ChatbotScreen.tsx`)

**Purpose:**
- AI-powered medical assistant
- Provides instant medical guidance
- Available 24/7 for health-related questions

**UI Elements:**
- **Header**: "المساعد الطبي الذكي" (Smart Medical Assistant)
- **Main Area**: Robot image background (centered)
- **Input Bar** (bottom):
  - Text input field: "اسأل عن أي شيء" (Ask anything)
  - Send button (gradient circle)

**Inputs:**
- **Message Input**: Text field for user questions

**Buttons:**
- **Send Button**: Sends question to AI chatbot

**User Flow:**
1. User types medical question
2. User taps Send button → AI responds with guidance
3. User continues conversation for medical advice

**Note:** This is a placeholder UI. In production, this would integrate with an AI medical chatbot API.

---

### 12. Profile Screen (`ProfileScreen.tsx`)

**Purpose:**
- Displays user's personal profile
- Shows user statistics (followers/following)
- Displays user's posts
- Provides access to profile editing and role-specific features

**UI Elements:**
- **Header**: Gradient background with "ملفي الشخصي" (My Profile)
- **Profile Card** containing:
  - User avatar (large, centered)
  - User name
  - Role indicator (for doctors)
  - **Edit Profile Button**
  - **Role-Specific Button**:
    - Doctors: "مرضاي" (My Patients) button
    - Parents: "طلب انضمام لطبيب" (Request to Join Doctor) button
  - **Statistics**: Followers and Following counts (tappable)
- **Posts Section**: "منشوراتي" (My Posts)
  - List of user's posts with like/comment counts

**Buttons:**
- **"تعديل الملف الشخصي" (Edit Profile)**: Opens Edit Profile Screen
- **"مرضاي" (My Patients)** (Doctor only): Opens My Patients Screen
- **"طلب انضمام لطبيب" (Request to Join Doctor)** (Parent only): Opens Patient Request Screen
- **Followers Count**: Opens Followers Screen
- **Following Count**: Opens Following Screen
- **Comment Icon** (on posts): Opens Comments Screen for that post

**User Flow:**
1. User views their profile and statistics
2. User taps "تعديل الملف الشخصي" → Edits profile
3. Doctor taps "مرضاي" → Manages patients
   OR
4. Parent taps "طلب انضمام لطبيب" → Sends join request to doctor
5. User taps Followers/Following counts → Views lists
6. User taps on own post → Views comments

---

## Social Features

### 13. Create Post Screen (`CreatePostScreen.tsx`)

**Purpose:**
- Allows users to create new community posts
- Share health tips, experiences, or questions
- Optional image attachment

**UI Elements:**
- **Header**: "إنشاء منشور" (Create Post) with back and publish buttons
- **User Info**: Shows user avatar, name, and role
- **Post Textarea**: Large text area for post content
- **Media Button**: "إضافة صورة" (Add Image) button
- **Guidelines Card**: Community guidelines with bullet points

**Inputs:**
- **Post Content Textarea**: "بماذا تفكر؟" (What are you thinking?) - multiline text input

**Buttons:**
- **Back Button** (header): Returns to Community Screen without saving
- **"نشر" (Publish)** (header): Publishes post, returns to Community Screen
- **"إضافة صورة" (Add Image)**: Attaches image to post (currently non-functional)

**Guidelines Shown:**
- Be respectful and supportive
- Share useful health information
- Protect privacy - no personal medical details
- Consult professionals for medical advice

**User Flow:**
1. User types post content in textarea
2. User optionally taps "إضافة صورة" → Attaches image
3. User taps "نشر" → Post is published → Returns to Community Screen
   OR
4. User taps Back → Returns to Community Screen without posting

---

### 14. Edit Post Screen (`EditPostScreen.tsx`)

**Purpose:**
- Allows users to edit their existing posts
- Modify post content
- Optional image management

**UI Elements:**
- **Header**: "تعديل المنشور" (Edit Post) with back and save buttons
- **User Info**: Shows user avatar, name, and role
- **Post Textarea**: Pre-filled with existing post content
- **Media Button**: "إضافة صورة" (Add Image) button

**Inputs:**
- **Post Content Textarea**: Editable text with existing content

**Buttons:**
- **Back Button** (header): Returns to Community Screen without saving changes
- **"حفظ" (Save)** (header): Saves changes, returns to Community Screen
- **"إضافة صورة" (Add Image)**: Attaches/changes image (currently non-functional)

**User Flow:**
1. User modifies post content
2. User taps "حفظ" → Changes saved → Returns to Community Screen
   OR
3. User taps Back → Returns to Community Screen without saving

---

### 15. Comments Screen (`CommentsScreen.tsx`)

**Purpose:**
- Displays all comments on a specific post
- Allows users to add new comments
- Shows original post for context

**UI Elements:**
- **Header**: "التعليقات" (Comments) with back button
- **Original Post Card**: Shows post author, content in highlighted card
- **Comments List**: Scrollable list of comments, each showing:
  - Commenter avatar
  - Commenter name
  - Comment text in bubble
  - Timestamp
  - Like count with heart icon
- **Comment Input Bar** (bottom):
  - User avatar
  - Text input field
  - Send button

**Inputs:**
- **Comment Input**: "اكتب تعليقاً..." (Write a comment...) text field

**Buttons:**
- **Back Button**: Returns to Community Screen or Profile Screen
- **Heart Icon** (on comments): Likes individual comment
- **Send Button**: Posts new comment

**User Flow:**
1. User views original post and existing comments
2. User types comment in input field
3. User taps Send → Comment appears in list
4. User taps heart on comments → Likes comment
5. User taps Back → Returns to previous screen

---

### 16. Search Screen (`SearchScreen.tsx`)

**Purpose:**
- Search for other users (doctors or parents)
- Discover new people to follow
- Connect with healthcare professionals

**UI Elements:**
- **Header**: "البحث" (Search) with back button
- **Search Bar**: Text input to search users
- **Results Section**: "النتائج" (Results)
- **User Cards**: Each card shows:
  - User avatar
  - User name
  - Role (طبيب قلب, مستخدم, etc.)
  - Follower count
  - Follow button

**Inputs:**
- **Search Bar**: "ابحث عن مستخدمين..." (Search for users...) text input

**Buttons:**
- **Back Button**: Returns to Community Screen
- **"متابعة" (Follow)** button on each user: Follows that user

**User Flow:**
1. User types search query
2. Results filter based on search
3. User taps "متابعة" on desired user → Follows them
4. User taps on user card → Views their profile (currently opens generic profile)
5. User taps Back → Returns to Community Screen

---

### 17. Followers Screen (`FollowersScreen.tsx`)

**Purpose:**
- Lists all users following the current user
- Shows follow status for each follower
- Can be used to start new chats (when accessed from Chat List)

**UI Elements:**
- **Header**: "المتابعون" (Followers) OR "بدء محادثة جديدة" (Start New Chat) with back button
- **User Cards**: Each card shows:
  - User avatar
  - User name
  - User role
  - Action button (Follow/Following OR Chat)

**Buttons:**
- **Back Button**: Returns to Profile Screen or Chat List
- **"متابعة" (Follow)** button: Follows user back (if not already following)
- **"متابَع" (Following)** button: Already following (can unfollow)
- **"دردشة" (Chat)** button (when in new chat mode): Starts chat with selected user

**User Flow - Normal Mode:**
1. User views followers list
2. User taps "متابعة" on unfollowed follower → Follows them back

**User Flow - New Chat Mode:**
1. User (from Chat List) taps Plus button → Opens this screen
2. User selects follower to chat with
3. User taps "دردشة" → Opens Chat Screen with selected user

---

### 18. Following Screen (`FollowingScreen.tsx`)

**Purpose:**
- Lists all users the current user is following
- Manage following relationships
- View profiles of followed users

**UI Elements:**
- **Header**: "المتابَعون" (Following) with back button
- **User Cards**: Each card shows:
  - User avatar
  - User name
  - User role
  - "متابَع" (Following) button

**Buttons:**
- **Back Button**: Returns to Profile Screen
- **"متابَع" (Following)** button: Already following (can tap to unfollow)
- **User Card**: Taps anywhere → Views User Profile Screen

**User Flow:**
1. User views list of people they follow
2. User taps on user card → Views that user's profile
3. User taps "متابَع" button → Unfollows that user

---

### 19. User Profile Screen (`UserProfileScreen.tsx`)

**Purpose:**
- View another user's public profile
- See their posts and statistics
- Send messages or follow them

**UI Elements:**
- **Header**: "الملف الشخصي" (Profile) with back button
- **Profile Card** containing:
  - User avatar
  - User name
  - User role
  - Action buttons (Message + Follow)
  - Statistics (Followers + Following counts)
- **Posts Section**: "المنشورات" (Posts)
  - List of user's public posts

**Buttons:**
- **Back Button**: Returns to previous screen
- **"رسالة" (Message)** button: Opens Chat Screen with this user
- **"متابعة" (Follow)** button: Follows this user
- **Followers Count**: Opens that user's Followers Screen
- **Following Count**: Opens that user's Following Screen
- **Post interaction buttons**: Like and comment on posts

**User Flow:**
1. User views another user's profile and posts
2. User taps "رسالة" → Opens chat with that user
3. User taps "متابعة" → Follows that user
4. User taps Followers/Following counts → Views their social connections
5. User taps Back → Returns to previous screen

---

## Patient Management (Doctor-Only)

### 20. Patient Request Screen (`PatientRequestScreen.tsx`) - **Parent Only**

**Purpose:**
- Allows parents to join a doctor's patient list
- Enter doctor-provided invitation code
- Send join request to doctor

**UI Elements:**
- **Header**: "طلب انضمام للطبيب" (Request to Join Doctor) with back button
- **Instruction Card**: Blue gradient card with:
  - Send icon
  - Title: "أدخل كود الطبيب" (Enter Doctor Code)
  - Description of process
- **Code Input Form**:
  - 6-character code input field (uppercase)
  - Character counter (X/6)
- **Submit Button**: "إرسال الطلب" (Send Request)
- **Help Card**: Notes about code usage
- **Success Screen** (after submission):
  - Checkmark icon
  - Success message

**Inputs:**
- **Doctor Code**: 6-character uppercase alphanumeric input

**Buttons:**
- **Back Button**: Returns to Profile Screen
- **"إرسال الطلب" (Send Request)**: Submits request to doctor (disabled until 6 characters entered)

**Help Notes Shown:**
- Request code directly from your doctor
- Code valid for 24 hours only
- You'll be notified when doctor accepts

**User Flow:**
1. Parent obtains 6-character code from doctor
2. Parent enters code in input field
3. Parent taps "إرسال الطلب" → Request sent
4. Success message appears
5. Auto-returns to Profile Screen after 2 seconds

---

### 21. Patient Details Screen (`PatientDetailsScreen.tsx`) - **Doctor Only**

**Purpose:**
- Doctor views detailed information about a specific patient
- Access to patient's emotional analysis history
- Monitor patient's progress over time

**UI Elements:**
- **Header**: "تفاصيل المريض" (Patient Details) with back button
- **Patient Info Card**: Blue gradient card showing:
  - Patient avatar
  - Patient name with user icon
  - Patient age with calendar icon
- **Analysis Section Header**: "التحليل" (Analysis) with right chevron
- **Analysis Cards**: Same format as Analysis Screen
  - Date/time stamps
  - Activity titles
  - Emotion pie charts
  - Emotion checklists

**Buttons:**
- **Back Button**: Returns to My Patients Screen
- **Right Chevron** (analysis header): Navigation action (currently non-functional)

**User Flow:**
1. Doctor taps on patient from My Patients list → Opens this screen
2. Doctor reviews patient info
3. Doctor scrolls through analysis history
4. Doctor interprets emotional patterns via charts
5. Doctor taps Back → Returns to My Patients Screen

---

## Profile & Settings

### 22. Edit Profile Screen (`EditProfileScreen.tsx`)

**Purpose:**
- Modify user account information
- Update personal details and child information (for parents)
- Access account actions (Sign Out, Delete Account)

**UI Elements:**
- **Header**: "تعديل الملف الشخصي" (Edit Profile) with back, save buttons
- **Profile Picture Section**:
  - Current avatar
  - Camera button overlay
  - "اضغط لتغيير الصورة" (Tap to change photo) text
- **Form Fields** (pre-filled with current data):
  - Full Name
  - Email
  - Phone Number
  - Child Name (parent only)
  - Child Age (parent only)
- **Account Actions Section**:
  - Sign Out button
  - Delete Account button (with confirmation dialog)

**Inputs:**
- **Full Name**: Text input
- **Email**: Email input
- **Phone Number**: Phone input
- **Child Name**: Text input (parent only)
- **Child Age**: Number input (parent only)

**Buttons:**
- **Back Button** (header): Returns to Profile Screen without saving
- **"حفظ" (Save)** (header): Saves changes, returns to Profile Screen
- **Camera Button** (on avatar): Changes profile picture
- **"تسجيل الخروج" (Sign Out)**: Signs out user, returns to Sign In Screen
- **"حذف الحساب" (Delete Account)**: Opens confirmation dialog
  - **Dialog buttons**:
    - "إلغاء" (Cancel): Closes dialog
    - "نعم، احذف الحساب" (Yes, Delete Account): Deletes account, returns to Role Selection

**User Flow:**
1. User modifies profile information
2. User taps "حفظ" → Changes saved → Returns to Profile Screen
   OR
3. User taps "تسجيل الخروج" → Signed out → Returns to Sign In Screen
   OR
4. User taps "حذف الحساب" → Confirmation dialog appears
5. User taps "نعم، احذف الحساب" → Account deleted → Returns to Role Selection

---

## Password Recovery

### 23. Forgot Password Screen (`ForgotPasswordScreen.tsx`)

**Purpose:**
- Initiates password recovery process
- Uses phone number for verification (not email)
- Sends verification code via SMS

**UI Elements:**
- **Header**: Back button, title "نسيت كلمة المرور؟" (Forgot Password?)
- **Description**: "أدخل رقم هاتفك وسنرسل لك رمز التحقق" (Enter your phone number and we'll send you a verification code)
- **Phone Input**: Phone number field with phone icon
- **Submit Button**: "إرسال رمز التحقق" (Send Verification Code)
  - Shows loading state when submitting
- **Help Card**: Information about SMS delivery

**Inputs:**
- **Phone Number**: Phone input field, placeholder: "+966 50 123 4567"

**Buttons:**
- **Back Button**: Returns to Sign In Screen
- **"إرسال رمز التحقق" (Send Verification Code)**: Sends SMS code (disabled until phone entered)
  - Shows spinner and "جاري الإرسال..." (Sending...) when processing

**Help Text Shown:**
- Verification code will be sent via SMS
- May take a few minutes to arrive

**User Flow:**
1. User enters phone number
2. User taps "إرسال رمز التحقق" → Code sent via SMS
3. Loading state shows briefly
4. User navigates to Verification Code Screen

---

### 24. Verification Code Screen (`VerificationCodeScreen.tsx`)

**Purpose:**
- Verify phone number ownership
- Enter 6-digit code received via SMS
- Proceed to password reset

**UI Elements:**
- **Header**: Back button, title "رمز التحقق" (Verification Code)
- **Description**: Shows phone number where code was sent
- **Code Input**: 6-digit numeric input (large, centered, with tracking)
- **Character Counter**: "X/6 أرقام"
- **Submit Button**: "تحقق" (Verify)
- **Resend Section**:
  - "لم تستلم الرمز؟" (Didn't receive code?)
  - "إعادة إرسال الرمز" (Resend Code) link

**Inputs:**
- **Verification Code**: 6-digit number input, centered with wide letter spacing

**Buttons:**
- **Back Button**: Returns to Forgot Password Screen
- **"تحقق" (Verify)**: Verifies code (disabled until 6 digits entered)
  - Shows spinner and "جاري التحقق..." (Verifying...) when processing
- **"إعادة إرسال الرمز" (Resend Code)**: Sends new code

**Validation:**
- Only accepts numeric input
- Requires exactly 6 digits
- Shows error if code is invalid

**User Flow:**
1. User receives SMS with 6-digit code
2. User enters code in input field
3. User taps "تحقق" → Code verified → Navigates to Reset Password Screen
   OR
4. User taps "إعادة إرسال الرمز" → New code sent
5. User taps Back → Returns to Forgot Password Screen

---

### 25. Reset Password Screen (`ResetPasswordScreen.tsx`)

**Purpose:**
- Set new password after verification
- Ensures password meets security requirements
- Confirms password match

**UI Elements:**
- **Header**: Back button, title "إعادة تعيين كلمة المرور" (Reset Password)
- **Description**: "أدخل كلمة المرور الجديدة" (Enter new password)
- **Form Fields**:
  - New Password input with show/hide toggle
  - Confirm Password input with show/hide toggle
  - Password requirement text
- **Submit Button**: "إعادة تعيين كلمة المرور" (Reset Password)
- **Error Message** (if validation fails)

**Inputs:**
- **New Password**: Password input with Eye/EyeOff toggle button
- **Confirm Password**: Password input with Eye/EyeOff toggle button

**Buttons:**
- **Back Button**: Returns to Verification Code Screen
- **Eye/EyeOff Toggles**: Show/hide password text
- **"إعادة تعيين كلمة المرور" (Reset Password)**: Submits new password
  - Shows spinner and "جاري التحديث..." (Updating...) when processing

**Validation Rules:**
- Password must be at least 8 characters
- Passwords must match
- Shows error messages for invalid inputs

**User Flow:**
1. User enters new password (at least 8 characters)
2. User re-enters password in confirm field
3. User taps "إعادة تعيين كلمة المرور" → Password updated
4. Success → Navigates to Sign In Screen
5. User can now sign in with new password

---

## Bottom Navigation Structure

**Parent Users See:**
1. **الرئيسية (Home)** → Community Screen
2. **التحليل (Analysis)** → Analysis Screen
3. **الدردشة (Chat)** → Chat List Screen
4. **المساعد الذكي (Smart Assistant)** → Chatbot Screen
5. **الملف (Profile)** → Profile Screen

**Doctor Users See:**
1. **الرئيسية (Home)** → Community Screen
2. **مرضاي (My Patients)** → My Patients Screen
3. **الدردشة (Chat)** → Chat List Screen
4. **المساعد الذكي (Smart Assistant)** → Chatbot Screen
5. **الملف (Profile)** → Profile Screen

---

## App State Flow Summary

```
Splash Screen (3s auto)
    ↓
Onboarding Screen (3 steps) → Skip Option
    ↓
Role Selection Screen
    ↓
    ├─→ Sign Up (Parent/Doctor) ←→ Sign In ←→ Forgot Password Flow
    │                                              ├─→ Verification Code
    │                                              └─→ Reset Password
    ↓
Main App (Bottom Navigation)
    ├─→ Community
    │      ├─→ Create Post
    │      ├─→ Edit Post
    │      ├─→ Comments
    │      └─→ Search
    ├─→ Analysis (Parent) / My Patients (Doctor)
    │      └─→ Patient Details (Doctor only)
    ├─→ Chat List
    │      ├─→ Chat Screen
    │      │      └─→ User Profile
    │      └─→ New Chat (Followers List)
    ├─→ Chatbot
    └─→ Profile
           ├─→ Edit Profile
           │      ├─→ Sign Out → Sign In
           │      └─→ Delete Account → Role Selection
           ├─→ Followers
           ├─→ Following
           ├─→ My Patients (Doctor only)
           │      └─→ Patient Details
           └─→ Patient Request (Parent only)
```

---

## Key Features Summary

### Authentication Features:
- Multi-step onboarding
- Role-based sign up (Doctor/Parent)
- Phone-based password recovery
- Account management (edit/delete)

### Social Features:
- Community feed with posts
- Like and comment system
- User search and discovery
- Follow/unfollow functionality
- User profiles (own and others)
- Direct messaging with online status

### Doctor-Specific Features:
- Patient list management
- Patient invitation system (6-character codes)
- Patient request approval system
- Individual patient analysis viewing
- Direct access to patients via bottom nav

### Parent-Specific Features:
- Child emotional analysis dashboard
- Request to join doctor's patient list
- Analysis history tracking
- Child information in profile

### Communication Features:
- Real-time chat with message history
- Voice call option (UI ready)
- AI medical chatbot
- Attachment support (UI ready)

### Design System:
- **Colors**: Light Blue (#E3F2FD), Medium Blue (#2196F3), Deep Blue (#1565C0)
- **Layout**: RTL (Right-to-Left) for Arabic
- **Spacing**: 8px system
- **Corners**: Rounded (2xl = 16px, 3xl = 24px)
- **Typography**: Arabic font optimized
- **Icons**: Lucide React icon library

---

## Developer Notes

### Current Limitations (Placeholder Functionality):
- Chatbot responses are not implemented (requires AI API integration)
- Voice calls UI is ready but not functional
- Image uploads show UI but don't process files
- Real-time chat uses mock data (needs WebSocket/backend)
- Analysis data is hardcoded (needs backend integration)
- Authentication is simulated (needs real auth service)

### Future Enhancements Needed:
- Backend API integration for all data operations
- Real-time messaging via WebSocket
- AI chatbot integration (OpenAI/custom medical model)
- Image upload and storage
- Voice/video calling functionality
- Push notifications for messages and requests
- Advanced search with filters
- Post media attachments (images/videos)
- Analytics dashboard for doctors
- Appointment scheduling system

### Testing Considerations:
- Test both Parent and Doctor user flows
- Verify RTL layout on all screens
- Test form validations
- Verify navigation flows between all screens
- Test empty states (no posts, no chats, etc.)
- Verify role-based feature access
- Test patient request acceptance/rejection flow
- Verify code generation and entry flows

---

**Last Updated:** February 18, 2026  
**App Version:** 1.0  
**Language:** Arabic (RTL)  
**Platform:** Mobile Web Application (Flutter-ready Material 3 design)
