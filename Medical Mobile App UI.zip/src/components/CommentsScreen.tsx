import { ArrowLeft, Heart, Send } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Card } from "./ui/card";
import { Input } from "./ui/input";
import { Button } from "./ui/button";

interface CommentsScreenProps {
  onBack: () => void;
  postAuthor: string;
  postContent: string;
}

const comments = [
  {
    id: 1,
    author: "د. فاطمة علي",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=fatima",
    content: "نصيحة رائعة! شكراً على المشاركة.",
    likes: 12,
    timestamp: "منذ ساعة",
  },
  {
    id: 2,
    author: "محمد أحمد",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=mohamed",
    content: "مفيد جداً، سأجرب هذا مع ابني.",
    likes: 8,
    timestamp: "منذ ساعتين",
  },
  {
    id: 3,
    author: "سارة خالد",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=sarah",
    content: "هل يمكنك مشاركة المزيد من التفاصيل؟",
    likes: 5,
    timestamp: "منذ 3 ساعات",
  },
];

export default function CommentsScreen({ onBack, postAuthor, postContent }: CommentsScreenProps) {
  return (
    <div className="min-h-screen w-full bg-white flex flex-col" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 bg-gradient-to-r from-[#2196F3] to-[#1565C0] px-6 py-4 flex items-center gap-4 shadow-md z-10">
        <button onClick={onBack} className="text-white">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl text-white">التعليقات</h1>
      </div>

      {/* Original Post */}
      <div className="px-4 py-4 border-b border-[#E3F2FD] bg-[#E3F2FD]">
        <Card className="p-4 rounded-2xl shadow-sm border-0 bg-white">
          <div className="flex items-start gap-3 mb-3 flex-row-reverse">
            <div className="flex-1 text-right">
              <h4 className="text-[#1a1a2e]">{postAuthor}</h4>
            </div>
            <Avatar className="w-10 h-10">
              <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=post" />
              <AvatarFallback>{postAuthor[0]}</AvatarFallback>
            </Avatar>
          </div>
          <p className="text-[#1a1a2e] text-right">{postContent}</p>
        </Card>
      </div>

      {/* Comments List */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {comments.map((comment) => (
          <div key={comment.id} className="flex items-start gap-3 flex-row-reverse justify-end">
            <Avatar className="w-10 h-10">
              <AvatarImage src={comment.avatar} />
              <AvatarFallback>{comment.author[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="bg-[#E3F2FD] rounded-2xl px-4 py-3">
                <h4 className="text-[#1a1a2e] mb-1 text-right">{comment.author}</h4>
                <p className="text-[#1a1a2e] text-right">{comment.content}</p>
              </div>
              <div className="flex items-center gap-4 mt-2 px-2 flex-row-reverse justify-end">
                <span className="text-sm text-[#64748b]">{comment.timestamp}</span>
                <button className="flex items-center gap-1 text-sm text-[#64748b] hover:text-[#2196F3]">
                  <span>{comment.likes}</span>
                  <Heart className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Comment Input */}
      <div className="sticky bottom-0 bg-white border-t border-[#E3F2FD] px-6 py-4">
        <div className="flex items-center gap-3">
          <Avatar className="w-9 h-9">
            <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=profile" />
            <AvatarFallback>أن</AvatarFallback>
          </Avatar>
          <Input
            placeholder="اكتب تعليقاً..."
            className="flex-1 h-12 rounded-full border-[#E3F2FD] bg-[#E3F2FD] focus:border-[#2196F3] focus:ring-[#2196F3] px-5 text-right"
          />
          <Button
            size="icon"
            className="w-12 h-12 rounded-full bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90 shadow-lg"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
