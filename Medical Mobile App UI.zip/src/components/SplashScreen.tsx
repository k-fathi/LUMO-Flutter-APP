import { motion } from "motion/react";
import lumoLogo from "figma:asset/e038b1af61c3f07a311d9a957a2f820843644e3c.png";

export default function SplashScreen() {
  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-[#E3F2FD] to-white flex items-center justify-center" dir="rtl">
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="flex flex-col items-center gap-6"
      >
        <motion.div
          animate={{
            y: [0, -20, 0],
          }}
          transition={{
            duration: 2,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="relative w-full max-w-sm px-8"
        >
          <img 
            src={lumoLogo}
            alt="LUMO" 
            className="w-full h-auto object-contain"
          />
        </motion.div>
      </motion.div>
    </div>
  );
}