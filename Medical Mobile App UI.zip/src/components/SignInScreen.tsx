import { Heart, Mail, Lock } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";

interface SignInScreenProps {
  onSignIn: () => void;
  onSignUpClick: () => void;
  onForgotPassword?: () => void;
}

export default function SignInScreen({ onSignIn, onSignUpClick, onForgotPassword }: SignInScreenProps) {
  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-[#E3F2FD] to-white flex items-center justify-center" dir="rtl">
      <div className="max-w-md w-full mx-auto px-6 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-gradient-to-br from-[#2196F3] to-[#1565C0] rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg">
            <Heart className="w-10 h-10 text-white fill-white" />
          </div>
          <h1 className="text-3xl text-[#1a1a2e] mb-2">مرحباً بعودتك</h1>
          <p className="text-[#64748b]">سجل الدخول لمتابعة رحلتك الصحية</p>
        </div>

        {/* Form */}
        <div className="space-y-5 mb-6">
          <div>
            <Label htmlFor="email" className="mb-2 block text-[#1a1a2e] text-right">البريد الإلكتروني</Label>
            <div className="relative">
              <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="email"
                type="email"
                placeholder="أدخل بريدك الإلكتروني"
                className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="password" className="mb-2 block text-[#1a1a2e] text-right">كلمة المرور</Label>
            <div className="relative">
              <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="password"
                type="password"
                placeholder="أدخل كلمة المرور"
                className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
              />
            </div>
          </div>

          {/* Forgot Password */}
          <div className="text-right">
            <button onClick={onForgotPassword} className="text-[#2196F3] hover:underline">
              نسيت كلمة المرور؟
            </button>
          </div>
        </div>

        {/* Sign In Button */}
        <Button
          onClick={onSignIn}
          className="w-full h-14 rounded-2xl bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90 text-white shadow-lg mb-6"
        >
          تسجيل الدخول
        </Button>

        {/* Sign Up Link */}
        <p className="text-center text-[#64748b]">
          ليس لديك حساب؟{" "}
          <button onClick={onSignUpClick} className="text-[#2196F3]">
            إنشاء حساب
          </button>
        </p>
      </div>
    </div>
  );
}
