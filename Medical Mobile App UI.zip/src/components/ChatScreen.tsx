import { ArrowLeft, Send, Paperclip, MoreVertical, Phone } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";

interface ChatScreenProps {
  onViewProfile?: () => void;
  onBack?: () => void;
}

const messages = [
  {
    id: 1,
    sender: "doctor",
    text: "مرحباً! لقد راجعت نتائج الفحوصات الأخيرة لابنتك. كل شيء يبدو جيداً بشكل عام.",
    time: "10:30 صباحاً",
  },
  {
    id: 2,
    sender: "user",
    text: "هذا رائع! هل يجب أن نستمر بنفس الدواء الحالي؟",
    time: "10:32 صباحاً",
  },
  {
    id: 3,
    sender: "doctor",
    text: "نعم، يرجى الاستمرار بنفس الجرعة لمدة أسبوعين آخرين. أود جدولة موعد متابعة لمراقبة التقدم.",
    time: "10:33 صباحاً",
  },
  {
    id: 4,
    sender: "user",
    text: "ممتاز. هل هناك أي قيود غذائية يجب أن نكون على علم بها؟",
    time: "10:35 صباحاً",
  },
  {
    id: 5,
    sender: "doctor",
    text: "لا توجد قيود محددة، لكنني أوصي بالحفاظ على نظام غذائي متوازن مع الكثير من الفواكه والخضروات. تجنبي الإفراط في تناول السكر.",
    time: "10:36 صباحاً",
  },
];

export default function ChatScreen({ onViewProfile, onBack }: ChatScreenProps) {
  return (
    <div className="min-h-screen w-full bg-white flex flex-col" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#2196F3] to-[#1565C0] px-6 py-4 flex items-center gap-4">
        <button onClick={onBack} className="text-white">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <button onClick={onViewProfile} className="flex items-center gap-3 flex-1">
          <Avatar className="w-10 h-10 border-2 border-white">
            <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=doctor" />
            <AvatarFallback>د</AvatarFallback>
          </Avatar>
          <div className="flex-1 text-right">
            <h2 className="text-white">د. سارة أحمد</h2>
            <p className="text-white/80 text-sm">نشط الآن</p>
          </div>
        </button>
        <button className="text-white">
          <Phone className="w-6 h-6" />
        </button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="text-white">
              <MoreVertical className="w-6 h-6" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-40" dir="rtl">
            <DropdownMenuItem onClick={onViewProfile} className="cursor-pointer">
              عرض الملف الشخصي
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer text-[#ef4444]">
              حظر المستخدم
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-6 py-6 space-y-4 bg-[#E3F2FD]">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${
              message.sender === "user" ? "justify-start" : "justify-end"
            }`}
          >
            <div
              className={`max-w-[75%] ${
                message.sender === "user"
                  ? "bg-gradient-to-r from-[#2196F3] to-[#1565C0] text-white rounded-[20px] rounded-tr-sm"
                  : "bg-white text-[#1a1a2e] rounded-[20px] rounded-tl-sm shadow-md"
              } px-5 py-3`}
            >
              <p className="mb-1">{message.text}</p>
              <p
                className={`text-xs ${
                  message.sender === "user" ? "text-white/70" : "text-[#64748b]"
                }`}
              >
                {message.time}
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Input Area */}
      <div className="bg-white border-t border-[#E3F2FD] px-6 py-4">
        <div className="flex items-center gap-3">
          <button className="text-[#2196F3] hover:text-[#1565C0]">
            <Paperclip className="w-6 h-6" />
          </button>
          <Input
            placeholder="اكتب رسالة..."
            className="flex-1 h-12 rounded-full border-[#E3F2FD] bg-[#E3F2FD] focus:border-[#2196F3] focus:ring-[#2196F3] px-5 text-right"
          />
          <Button
            size="icon"
            className="w-12 h-12 rounded-full bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90 shadow-lg"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
