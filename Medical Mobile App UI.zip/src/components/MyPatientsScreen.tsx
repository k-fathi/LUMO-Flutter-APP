import { ArrowLeft, Plus, User, Check, X } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { useState } from "react";

interface MyPatientsScreenProps {
  onBack: () => void;
  onPatientClick?: (patient: { id: number; name: string; age: number; avatar: string }) => void;
}

const patients = [
  {
    id: 1,
    name: "أحمد محمد",
    age: 8,
    lastVisit: "منذ 3 أيام",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=ahmed",
  },
  {
    id: 2,
    name: "فاطمة علي",
    age: 5,
    lastVisit: "منذ أسبوع",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=fatima",
  },
  {
    id: 3,
    name: "عمر حسن",
    age: 12,
    lastVisit: "منذ يومين",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=omar",
  },
  {
    id: 4,
    name: "ليلى خالد",
    age: 3,
    lastVisit: "اليوم",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=layla",
  },
  {
    id: 5,
    name: "يوسف سالم",
    age: 10,
    lastVisit: "منذ 5 أيام",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=yousef",
  },
];

const pendingRequests = [
  {
    id: 1,
    name: "سارة أحمد",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=sara",
    requestTime: "منذ ساعة",
  },
  {
    id: 2,
    name: "محمد حسين",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=mohamed",
    requestTime: "منذ 3 ساعات",
  },
  {
    id: 3,
    name: "نور عبدالله",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=noor",
    requestTime: "منذ 5 ساعات",
  },
];

function generateCode(): string {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let code = '';
  for (let i = 0; i < 6; i++) {
    code += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return code;
}

export default function MyPatientsScreen({ onBack, onPatientClick }: MyPatientsScreenProps) {
  const [generatedCode, setGeneratedCode] = useState<string>("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [requests, setRequests] = useState(pendingRequests);

  const handleGenerateCode = () => {
    const code = generateCode();
    setGeneratedCode(code);
    setIsDialogOpen(true);
  };

  const handleAccept = (requestId: number) => {
    setRequests(requests.filter(req => req.id !== requestId));
    // In a real app, this would accept the patient and add them to the patients list
  };

  const handleReject = (requestId: number) => {
    setRequests(requests.filter(req => req.id !== requestId));
    // In a real app, this would reject the request
  };

  return (
    <div className="min-h-screen w-full bg-white pb-24" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 bg-gradient-to-r from-[#2196F3] to-[#1565C0] px-6 py-4 shadow-md z-10">
        <div className="flex items-center justify-between mb-3">
          <button onClick={onBack} className="text-white">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl text-white">مرضاي</h1>
          <div className="w-6" /> {/* Spacer for centering */}
        </div>
        
        {/* New Code Button */}
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <button
              onClick={handleGenerateCode}
              className="w-full h-12 rounded-xl bg-white text-[#2196F3] hover:bg-[#E3F2FD] flex items-center justify-center gap-2 transition-colors"
            >
              <Plus className="w-5 h-5 mr-2" />
              كود جديد
            </button>
          </DialogTrigger>
          <DialogContent className="max-w-sm mx-auto" dir="rtl">
            <DialogHeader>
              <DialogTitle className="text-center text-xl text-[#1a1f36]">كود الدخول</DialogTitle>
              <DialogDescription className="text-center text-sm text-[#64748b]">
                استخدم هذا الكود لإضافة مريض جديد
              </DialogDescription>
            </DialogHeader>
            <div className="py-6">
              <div className="bg-gradient-to-br from-[#2196F3] to-[#1565C0] rounded-2xl p-8 text-center">
                <p className="text-white text-sm mb-3">شارك هذا الكود مع المريض</p>
                <p className="text-white text-4xl tracking-[0.5em] mb-4">{generatedCode}</p>
                <p className="text-white/80 text-xs">صالح لمدة 24 ساعة</p>
              </div>
              <div className="mt-6 space-y-2">
                <Button
                  onClick={() => {
                    navigator.clipboard.writeText(generatedCode);
                  }}
                  className="w-full h-12 rounded-xl bg-[#E3F2FD] text-[#2196F3] hover:bg-[#BBDEFB]"
                >
                  نسخ الكود
                </Button>
                <Button
                  onClick={() => setIsDialogOpen(false)}
                  variant="outline"
                  className="w-full h-12 rounded-xl border-2 border-[#E3F2FD] text-[#64748b] hover:bg-[#E3F2FD]"
                >
                  إغلاق
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Total Patients */}
      <div className="px-6 py-6">
        <div className="bg-gradient-to-br from-[#2196F3] to-[#1565C0] rounded-2xl p-6 shadow-lg">
          <div className="flex items-center justify-between">
            <div className="text-right">
              <p className="text-white/80 text-sm mb-1">إجمالي المرضى</p>
              <p className="text-white text-4xl">{patients.length}</p>
            </div>
            <div className="bg-white/20 rounded-full p-4">
              <User className="w-8 h-8 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Pending Requests Section */}
      {requests.length > 0 && (
        <div className="px-6 pb-6">
          <h3 className="text-lg text-[#1a1f36] mb-4 text-right">طلبات الانضمام</h3>
          <div className="space-y-3">
            {requests.map((request) => (
              <Card key={request.id} className="p-4 rounded-2xl shadow-sm border-[#E3F2FD] hover:shadow-md transition-shadow">
                <div className="flex items-center gap-4">
                  <Avatar className="w-14 h-14">
                    <AvatarImage src={request.avatar} />
                    <AvatarFallback>{request.name[0]}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 text-right">
                    <h4 className="text-[#1a1f36] mb-1">{request.name}</h4>
                    <p className="text-sm text-[#64748b]">{request.requestTime}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => handleReject(request.id)}
                      variant="outline"
                      className="h-10 w-10 p-0 rounded-xl border-2 border-red-200 text-red-500 hover:bg-red-50"
                    >
                      <X className="w-5 h-5" />
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleAccept(request.id)}
                      className="h-10 w-10 p-0 rounded-xl bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90"
                    >
                      <Check className="w-5 h-5" />
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* Patients List */}
      <div className="px-6 pb-6">
        <h3 className="text-lg text-[#1a1f36] mb-4 text-right">قائمة المرضى</h3>
        <div className="space-y-3">
          {patients.map((patient) => (
            <Card 
              key={patient.id} 
              className="p-4 rounded-2xl shadow-sm border-[#E3F2FD] hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => onPatientClick?.(patient)}
            >
              <div className="flex items-center gap-4">
                <Avatar className="w-14 h-14">
                  <AvatarImage src={patient.avatar} />
                  <AvatarFallback>{patient.name[0]}</AvatarFallback>
                </Avatar>
                <div className="flex-1 text-right">
                  <h4 className="text-[#1a1f36] mb-1">{patient.name}</h4>
                  <div className="flex items-center gap-3 text-sm text-[#64748b] flex-row-reverse justify-end">
                    <span>{patient.lastVisit}</span>
                    <span>•</span>
                    <span>{patient.age} سنوات</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
