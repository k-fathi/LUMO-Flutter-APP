import { ChevronRight, Circle } from "lucide-react";
import { Card } from "./ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";

const analysisData = [
  {
    date: "22/05/01 - 12:03",
    title: "الألغاز",
    emotions: [
      { name: "محايد", value: 56, color: "#2196F3" },
      { name: "حزين", value: 20, color: "#ec4899" },
    ],
    results: [
      { label: "محايد", checked: true },
      { label: "حزين", checked: true },
      { label: "خائف", checked: false },
      { label: "غاضب", checked: false },
      { label: "سعيد", checked: false },
    ],
  },
  {
    date: "22/05/01 - 12:03",
    title: "الألغاز",
    emotions: [
      { name: "محايد", value: 100, color: "#2196F3" },
    ],
    results: [
      { label: "محايد", checked: true },
      { label: "حزين", checked: false },
      { label: "خائف", checked: false },
      { label: "غاضب", checked: false },
      { label: "سعيد", checked: false },
    ],
  },
  {
    date: "22/05/01 - 12:03",
    title: "الألغاز",
    emotions: [
      { name: "محايد", value: 56, color: "#2196F3" },
      { name: "حزين", value: 20, color: "#ec4899" },
    ],
    results: [
      { label: "محايد", checked: true },
      { label: "حزين", checked: true },
      { label: "خائف", checked: false },
      { label: "غاضب", checked: false },
      { label: "سعيد", checked: false },
    ],
  },
];

export default function AnalysisScreen() {
  return (
    <div className="min-h-screen w-full bg-white pb-24" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-[#E3F2FD] px-6 py-4 flex items-center justify-between z-10">
        <h1 className="text-2xl text-[#1565C0]">التحليل</h1>
        <button className="text-[#2196F3]">
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      {/* Analysis Cards */}
      <div className="px-6 py-6 space-y-6">
        {analysisData.map((item, index) => (
          <Card key={index} className="p-6 rounded-3xl shadow-md border-[#E3F2FD]">
            {/* Date */}
            <p className="text-sm text-[#2196F3] mb-3 text-right">التاريخ: {item.date}</p>

            {/* Title */}
            <h3 className="text-xl text-[#1565C0] mb-6 text-right">{item.title}</h3>

            <div className="flex items-start gap-6">
              {/* Chart */}
              <div className="flex-shrink-0">
                <div className="w-28 h-28 relative">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={item.emotions}
                        cx="50%"
                        cy="50%"
                        innerRadius={30}
                        outerRadius={50}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {item.emotions.map((entry, idx) => (
                          <Cell key={`cell-${idx}`} fill={entry.color} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-sm text-[#64748b]">
                      {item.emotions[0].value}
                    </span>
                  </div>
                </div>
              </div>

              {/* Results */}
              <div className="flex-1 space-y-2">
                {item.results.map((result, idx) => (
                  <div key={idx} className="flex items-center gap-3 flex-row-reverse justify-end">
                    <span className="text-[#64748b]">{result.label}</span>
                    <Circle
                      className={`w-4 h-4 ${
                        result.checked
                          ? "fill-[#ec4899] text-[#ec4899]"
                          : "text-[#cbd5e1]"
                      }`}
                    />
                  </div>
                ))}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
