import { ArrowLeft, Camera, User, Mail, Phone, Baby, Calendar, LogOut, Trash2 } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "./ui/alert-dialog";

interface EditProfileScreenProps {
  onBack: () => void;
  onSignOut?: () => void;
  onDeleteAccount?: () => void;
}

export default function EditProfileScreen({ onBack, onSignOut, onDeleteAccount }: EditProfileScreenProps) {
  return (
    <div className="min-h-screen w-full bg-white pb-32" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 bg-gradient-to-r from-[#2196F3] to-[#1565C0] px-6 py-4 flex items-center justify-between shadow-md z-10">
        <button onClick={onBack} className="text-white">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl text-white">تعديل الملف الشخصي</h1>
        <Button
          className="bg-white text-[#2196F3] hover:bg-white/90 h-9 px-4 rounded-xl"
        >
          حفظ
        </Button>
      </div>

      {/* Content */}
      <div className="px-6 py-8">
        {/* Profile Picture */}
        <div className="flex flex-col items-center mb-8">
          <div className="relative">
            <Avatar className="w-28 h-28 border-4 border-[#E3F2FD]">
              <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=profile" />
              <AvatarFallback>أم</AvatarFallback>
            </Avatar>
            <button className="absolute bottom-0 right-0 w-10 h-10 bg-gradient-to-r from-[#2196F3] to-[#1565C0] rounded-full flex items-center justify-center shadow-lg">
              <Camera className="w-5 h-5 text-white" />
            </button>
          </div>
          <p className="text-sm text-[#64748b] mt-3">اضغط لتغيير الصورة</p>
        </div>

        {/* Form */}
        <div className="space-y-5">
          <div>
            <Label htmlFor="name" className="mb-2 block text-[#1a1a2e] text-right">الاسم الكامل</Label>
            <div className="relative">
              <User className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="name"
                type="text"
                defaultValue="أحمد محمد"
                className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-[#E3F2FD] focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="email" className="mb-2 block text-[#1a1a2e] text-right">البريد الإلكتروني</Label>
            <div className="relative">
              <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="email"
                type="email"
                defaultValue="ahmed@example.com"
                className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-[#E3F2FD] focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="phone" className="mb-2 block text-[#1a1a2e] text-right">رقم الهاتف</Label>
            <div className="relative">
              <Phone className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="phone"
                type="tel"
                defaultValue="+966 50 123 4567"
                className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-[#E3F2FD] focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="childName" className="mb-2 block text-[#1a1a2e] text-right">اسم الطفل</Label>
            <div className="relative">
              <Baby className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="childName"
                type="text"
                defaultValue="محمد"
                className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-[#E3F2FD] focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="childAge" className="mb-2 block text-[#1a1a2e] text-right">عمر الطفل</Label>
            <div className="relative">
              <Calendar className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="childAge"
                type="number"
                defaultValue="5"
                className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-[#E3F2FD] focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
              />
            </div>
          </div>
        </div>

        {/* Account Actions Section */}
        <div className="mt-12 space-y-3">
          {/* Sign Out Button */}
          <Button
            onClick={onSignOut}
            className="w-full h-12 rounded-xl bg-[#E3F2FD] text-[#2196F3] hover:bg-[#BBDEFB]"
          >
            <LogOut className="w-5 h-5 ml-2" />
            تسجيل الخروج
          </Button>

          {/* Delete Account Button with Confirmation Dialog */}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                className="w-full h-12 rounded-xl bg-[#fee] text-[#ef4444] hover:bg-[#fdd]"
              >
                <Trash2 className="w-5 h-5 ml-2" />
                حذف الحساب
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="max-w-[90%] rounded-3xl" dir="rtl">
              <AlertDialogHeader>
                <AlertDialogTitle className="text-right text-[#1a1f36]">
                  هل أنت متأكد من حذف الحساب؟
                </AlertDialogTitle>
                <AlertDialogDescription className="text-right text-[#64748b]">
                  هذا الإجراء لا يمكن التراجع عنه. سيتم حذف جميع بياناتك ومنشوراتك ورسائلك بشكل دائم.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter className="flex-row-reverse gap-3 sm:flex-row-reverse">
                <AlertDialogCancel className="flex-1 bg-[#E3F2FD] text-[#2196F3] hover:bg-[#BBDEFB] rounded-xl h-11 border-0 mt-0">
                  إلغاء
                </AlertDialogCancel>
                <AlertDialogAction
                  onClick={onDeleteAccount}
                  className="flex-1 bg-[#ef4444] hover:bg-[#dc2626] text-white rounded-xl h-11"
                >
                  نعم، احذف الحساب
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
    </div>
  );
}