import { ArrowLeft, Phone } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { useState } from "react";

interface ForgotPasswordScreenProps {
  onBack: () => void;
  onSendCode: (phone: string) => void;
}

export default function ForgotPasswordScreen({ onBack, onSendCode }: ForgotPasswordScreenProps) {
  const [phone, setPhone] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone) return;
    
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      onSendCode(phone);
    }, 1000);
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-[#E3F2FD] to-white flex flex-col" dir="rtl">
      {/* Header */}
      <div className="px-6 pt-12 pb-8">
        <button onClick={onBack} className="text-[#2196F3] mb-6">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-3xl text-[#1a1f36] mb-2 text-right">نسيت كلمة المرور؟</h1>
        <p className="text-[#64748b] text-right">
          أدخل رقم هاتفك وسنرسل لك رمز التحقق
        </p>
      </div>

      {/* Form */}
      <div className="flex-1 px-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="phone" className="mb-2 block text-[#1a1f36] text-right">
              رقم الهاتف
            </Label>
            <div className="relative">
              <Phone className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+966 50 123 4567"
                className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
                required
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={!phone || isSubmitting}
            className="w-full h-14 rounded-2xl bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90 disabled:opacity-50"
          >
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                جاري الإرسال...
              </span>
            ) : (
              "إرسال رمز التحقق"
            )}
          </Button>
        </form>

        {/* Help Text */}
        <div className="mt-8 p-4 bg-white rounded-2xl border border-[#E3F2FD]">
          <p className="text-sm text-[#64748b] text-right">
            سيتم إرسال رمز التحقق عبر رسالة نصية إلى رقم هاتفك. قد يستغرق الأمر بضع دقائق.
          </p>
        </div>
      </div>
    </div>
  );
}