import { ArrowLeft } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import { Card } from "./ui/card";

interface FollowingScreenProps {
  onBack: () => void;
  onViewProfile?: () => void;
}

const following = [
  {
    id: 1,
    name: "د. يوسف خالد",
    role: "طبيب عام",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=following1",
  },
  {
    id: 2,
    name: "ليلى سالم",
    role: "مستخدم",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=following2",
  },
  {
    id: 3,
    name: "د. عمر حسين",
    role: "طبيب أطفال",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=following3",
  },
  {
    id: 4,
    name: "نور محمد",
    role: "مستخدم",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=following4",
  },
];

export default function FollowingScreen({ onBack, onViewProfile }: FollowingScreenProps) {
  return (
    <div className="min-h-screen w-full bg-white" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 bg-gradient-to-r from-[#2196F3] to-[#1565C0] px-6 py-4 flex items-center gap-4 shadow-md z-10">
        <button onClick={onBack} className="text-white">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl text-white">المتابَعون</h1>
      </div>

      {/* Following List */}
      <div className="px-6 py-6 space-y-3">
        {following.map((user) => (
          <Card key={user.id} className="p-4 rounded-2xl shadow-sm border-[#E3F2FD] hover:shadow-md transition-shadow">
            <div className="flex items-center gap-4">
              <button onClick={onViewProfile} className="flex-shrink-0">
                <Avatar className="w-14 h-14">
                  <AvatarImage src={user.avatar} />
                  <AvatarFallback>{user.name[0]}</AvatarFallback>
                </Avatar>
              </button>
              <button onClick={onViewProfile} className="flex-1 text-right">
                <h4 className="text-[#1a1a2e] mb-1">{user.name}</h4>
                <p className="text-sm text-[#64748b]">{user.role}</p>
              </button>
              <Button
                size="sm"
                variant="outline"
                className="h-9 px-4 rounded-xl border-2 border-[#E3F2FD] text-[#64748b] hover:bg-[#E3F2FD]"
              >
                متابَع
              </Button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
