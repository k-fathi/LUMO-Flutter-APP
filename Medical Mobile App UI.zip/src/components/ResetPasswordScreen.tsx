import { ArrowLeft, Lock, Eye, EyeOff } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { useState } from "react";

interface ResetPasswordScreenProps {
  onBack: () => void;
  onReset: () => void;
}

export default function ResetPasswordScreen({ onBack, onReset }: ResetPasswordScreenProps) {
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (newPassword.length < 8) {
      setError("كلمة المرور يجب أن تكون 8 أحرف على الأقل");
      return;
    }
    
    if (newPassword !== confirmPassword) {
      setError("كلمتا المرور غير متطابقتين");
      return;
    }
    
    setIsSubmitting(true);
    setError("");
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      onReset();
    }, 1000);
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-[#E3F2FD] to-white flex flex-col" dir="rtl">
      {/* Header */}
      <div className="px-6 pt-12 pb-8">
        <button onClick={onBack} className="text-[#2196F3] mb-6">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-3xl text-[#1a1f36] mb-2 text-right">إعادة تعيين كلمة المرور</h1>
        <p className="text-[#64748b] text-right">
          أدخل كلمة المرور الجديدة
        </p>
      </div>

      {/* Form */}
      <div className="flex-1 px-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="newPassword" className="mb-2 block text-[#1a1f36] text-right">
              كلمة المرور الجديدة
            </Label>
            <div className="relative">
              <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="newPassword"
                type={showNewPassword ? "text" : "password"}
                value={newPassword}
                onChange={(e) => {
                  setNewPassword(e.target.value);
                  setError("");
                }}
                placeholder="••••••••"
                className="pr-12 pl-12 h-14 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
                required
              />
              <button
                type="button"
                onClick={() => setShowNewPassword(!showNewPassword)}
                className="absolute left-4 top-1/2 -translate-y-1/2 text-[#64748b] hover:text-[#2196F3]"
              >
                {showNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
            <p className="text-xs text-[#64748b] mt-2 text-right">
              يجب أن تكون 8 أحرف على الأقل
            </p>
          </div>

          <div>
            <Label htmlFor="confirmPassword" className="mb-2 block text-[#1a1f36] text-right">
              تأكيد كلمة المرور
            </Label>
            <div className="relative">
              <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="confirmPassword"
                type={showConfirmPassword ? "text" : "password"}
                value={confirmPassword}
                onChange={(e) => {
                  setConfirmPassword(e.target.value);
                  setError("");
                }}
                placeholder="••••••••"
                className="pr-12 pl-12 h-14 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
                required
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute left-4 top-1/2 -translate-y-1/2 text-[#64748b] hover:text-[#2196F3]"
              >
                {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {error && (
            <p className="text-sm text-red-500 text-center bg-red-50 p-3 rounded-xl">
              {error}
            </p>
          )}

          <Button
            type="submit"
            disabled={!newPassword || !confirmPassword || isSubmitting}
            className="w-full h-14 rounded-2xl bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90 disabled:opacity-50"
          >
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                جاري التحديث...
              </span>
            ) : (
              "إعادة تعيين كلمة المرور"
            )}
          </Button>
        </form>
      </div>
    </div>
  );
}
