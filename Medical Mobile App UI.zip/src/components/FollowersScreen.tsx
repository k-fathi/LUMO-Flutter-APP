import { ArrowLeft, MessageCircle } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import { Card } from "./ui/card";

interface FollowersScreenProps {
  onBack: () => void;
  onViewProfile?: () => void;
  onStartChat?: (followerId: number) => void;
  showChatOption?: boolean;
}

const followers = [
  {
    id: 1,
    name: "د. محمد أحمد",
    role: "طبيب قلب",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=follower1",
    isFollowingBack: true,
  },
  {
    id: 2,
    name: "سارة علي",
    role: "مستخدم",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=follower2",
    isFollowingBack: false,
  },
  {
    id: 3,
    name: "د. فاطمة حسن",
    role: "طبيبة أطفال",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=follower3",
    isFollowingBack: true,
  },
  {
    id: 4,
    name: "أحمد محمود",
    role: "مستخدم",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=follower4",
    isFollowingBack: true,
  },
];

export default function FollowersScreen({ onBack, onViewProfile, onStartChat, showChatOption = false }: FollowersScreenProps) {
  return (
    <div className="min-h-screen w-full bg-white" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 bg-gradient-to-r from-[#2196F3] to-[#1565C0] px-6 py-4 flex items-center gap-4 shadow-md z-10">
        <button onClick={onBack} className="text-white">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl text-white">{showChatOption ? "بدء محادثة جديدة" : "المتابعون"}</h1>
      </div>

      {/* Followers List */}
      <div className="px-6 py-6 space-y-3">
        {followers.map((follower) => (
          <Card key={follower.id} className="p-4 rounded-2xl shadow-sm border-[#E3F2FD] hover:shadow-md transition-shadow">
            <div className="flex items-center gap-4">
              <button onClick={onViewProfile} className="flex-shrink-0">
                <Avatar className="w-14 h-14">
                  <AvatarImage src={follower.avatar} />
                  <AvatarFallback>{follower.name[0]}</AvatarFallback>
                </Avatar>
              </button>
              <button onClick={onViewProfile} className="flex-1 text-right">
                <h4 className="text-[#1a1a2e] mb-1">{follower.name}</h4>
                <p className="text-sm text-[#64748b]">{follower.role}</p>
              </button>
              {showChatOption ? (
                <Button
                  onClick={() => onStartChat?.(follower.id)}
                  size="sm"
                  className="h-9 px-4 rounded-xl bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90 text-white"
                >
                  <MessageCircle className="w-4 h-4 ml-2" />
                  دردشة
                </Button>
              ) : (
                <Button
                  size="sm"
                  variant={follower.isFollowingBack ? "outline" : "default"}
                  className={`h-9 px-4 rounded-xl ${
                    follower.isFollowingBack
                      ? "border-2 border-[#E3F2FD] text-[#64748b] hover:bg-[#E3F2FD]"
                      : "bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90 text-white"
                  }`}
                >
                  {follower.isFollowingBack ? "متابَع" : "متابعة"}
                </Button>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}