import { ArrowLeft, MessageCircle, Heart } from "lucide-react";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Card } from "./ui/card";

interface UserProfileScreenProps {
  onBack: () => void;
  onChat?: () => void;
  onViewFollowers?: () => void;
  onViewFollowing?: () => void;
}

const userPosts = [
  {
    id: 1,
    content: "أردت فقط مشاركة تجربتي مع العيادة الجديدة للأطفال. كان الموظفون رائعين ومتفهمين جداً مع ابنتي. أوصي به بشدة للآباء الآخرين! 🏥",
    likes: 89,
    comments: 15,
    timestamp: "منذ يومين",
  },
  {
    id: 2,
    content: "أبحث عن نصائح حول إدارة حساسية الطعام لدى ابني. هل هناك آباء يتعاملون مع تحديات مماثلة؟ أود التواصل وتبادل الخبرات.",
    likes: 34,
    comments: 18,
    timestamp: "منذ 5 أيام",
  },
];

export default function UserProfileScreen({ onBack, onChat, onViewFollowers, onViewFollowing }: UserProfileScreenProps) {
  return (
    <div className="min-h-screen w-full bg-white pb-24" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#2196F3] to-[#1565C0] px-6 pt-12 pb-32 rounded-b-[32px] relative">
        <button onClick={onBack} className="absolute top-4 left-6 text-white">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <div className="flex justify-center items-center">
          <h1 className="text-2xl text-white">الملف الشخصي</h1>
        </div>
      </div>

      {/* Profile Info Card */}
      <div className="px-6 -mt-24 pb-6">
        <Card className="p-6 rounded-3xl shadow-lg border-0 bg-white">
          {/* Avatar and Basic Info */}
          <div className="flex flex-col items-center mb-6">
            <Avatar className="w-28 h-28 border-4 border-white shadow-lg mb-4">
              <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=user" />
              <AvatarFallback>س م</AvatarFallback>
            </Avatar>
            <h2 className="text-2xl text-[#1a1f36] mb-1">سارة محمود</h2>
            <p className="text-[#64748b] mb-4">مستخدم</p>

            {/* Action Buttons */}
            <div className="flex gap-3 w-full">
              <Button
                onClick={onChat}
                className="flex-1 h-12 rounded-xl bg-gradient-to-r from-[#2196F3] to-[#1565C0] text-white hover:opacity-90"
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                رسالة
              </Button>
              <Button
                variant="outline"
                className="flex-1 h-12 rounded-xl border-2 border-[#E3F2FD] text-[#2196F3] hover:bg-[#E3F2FD]"
              >
                متابعة
              </Button>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-4 py-4 border-t border-b border-[#E3F2FD]">
            <button onClick={onViewFollowers} className="text-center hover:bg-[#E3F2FD] rounded-xl py-2 transition-colors">
              <p className="text-2xl text-[#1a1f36] mb-1">1.2K</p>
              <p className="text-sm text-[#64748b]">المتابعون</p>
            </button>
            <button onClick={onViewFollowing} className="text-center hover:bg-[#E3F2FD] rounded-xl py-2 transition-colors">
              <p className="text-2xl text-[#1a1f36] mb-1">345</p>
              <p className="text-sm text-[#64748b]">المتابَعون</p>
            </button>
          </div>
        </Card>
      </div>

      {/* Posts Section */}
      <div className="px-6">
        <h3 className="text-xl text-[#1a1f36] mb-4 text-right">المنشورات</h3>
        <div className="space-y-4">
          {userPosts.map((post) => (
            <Card key={post.id} className="p-5 rounded-2xl shadow-sm border-[#E3F2FD]">
              <p className="text-[#1a1f36] mb-4 text-right">{post.content}</p>
              <div className="flex items-center gap-6 pt-3 border-t border-[#E3F2FD]">
                <button className="flex items-center gap-2 text-[#64748b] hover:text-[#ec4899] transition-colors">
                  <Heart className="w-5 h-5" />
                  <span>{post.likes}</span>
                </button>
                <button className="flex items-center gap-2 text-[#64748b] hover:text-[#2196F3] transition-colors">
                  <MessageCircle className="w-5 h-5" />
                  <span>{post.comments}</span>
                </button>
                <span className="text-sm text-[#64748b] mr-auto">{post.timestamp}</span>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
