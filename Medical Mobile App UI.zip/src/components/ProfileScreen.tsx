import { Edit, Heart, MessageCircle, Users, UserPlus } from "lucide-react";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Card } from "./ui/card";

interface ProfileScreenProps {
  role?: "doctor" | "parent";
  onEditProfile?: () => void;
  onViewFollowers?: () => void;
  onViewFollowing?: () => void;
  onViewComments?: (postId: number, author: string, content: string) => void;
  onViewPatients?: () => void;
  onPatientRequest?: () => void;
}

const parentPosts = [
  {
    id: 1,
    content: "أردت فقط مشاركة تجربتي مع العيادة الجديدة للأطفال. كان الموظفون متعاونين ومتفهمين جداً مع ابنتي. أوصي به للآباء الآخرين! 🏥",
    likes: 89,
    comments: 15,
    timestamp: "منذ يومين",
  },
  {
    id: 2,
    content: "أبحث عن نصائح بخصوص حساسية الطعام لدى ابني. هل يوجد آباء يواجهون تحديات مماثلة؟ أود التواصل وتبادل الخبرات.",
    likes: 34,
    comments: 18,
    timestamp: "منذ 5 أيام",
  },
];

const doctorPosts = [
  {
    id: 1,
    content: "نصائح مهمة للآباء: تأكدوا من حصول أطفالكم على التطعيمات في موعدها. الوقاية خير من العلاج دائماً! 💉",
    likes: 234,
    comments: 45,
    timestamp: "منذ يوم واحد",
  },
  {
    id: 2,
    content: "سعيد بالإعلان عن ورشة عمل مجانية حول التغذية الصحية للأطفال يوم السبت القادم. التسجيل متاح الآن!",
    likes: 189,
    comments: 67,
    timestamp: "منذ 3 أيام",
  },
];

export default function ProfileScreen({ 
  role = "parent", 
  onEditProfile,
  onViewFollowers,
  onViewFollowing,
  onViewComments,
  onViewPatients,
  onPatientRequest
}: ProfileScreenProps) {
  const isDoctor = role === "doctor";
  const userPosts = isDoctor ? doctorPosts : parentPosts;

  return (
    <div className="min-h-screen w-full bg-white pb-32" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#2196F3] to-[#1565C0] px-6 pt-12 pb-32 rounded-b-[32px] relative">
        <div className="flex justify-center items-center">
          <h1 className="text-2xl text-white">ملفي الشخصي</h1>
        </div>
      </div>

      {/* Profile Info Card */}
      <div className="px-6 -mt-24 pb-6">
        <Card className="p-6 rounded-3xl shadow-lg border-0 bg-white">
          {/* Avatar and Basic Info */}
          <div className="flex flex-col items-center mb-6">
            <Avatar className="w-28 h-28 border-4 border-white shadow-lg mb-4">
              <AvatarImage src={isDoctor ? "https://api.dicebear.com/7.x/avataaars/svg?seed=doctor" : "https://api.dicebear.com/7.x/avataaars/svg?seed=profile"} />
              <AvatarFallback>{isDoctor ? "د" : "إ"}</AvatarFallback>
            </Avatar>
            <h2 className="text-2xl text-[#1a1f36] mb-6">
              {isDoctor ? "د. سارة جونسون" : "إيميلي باركر"}
            </h2>

            {/* Edit Profile Button */}
            <Button
              onClick={onEditProfile}
              className="w-full h-12 rounded-xl bg-[#E3F2FD] text-[#2196F3] hover:bg-[#BBDEFB]"
            >
              <Edit className="w-5 h-5 mr-2" />
              تعديل الملف الشخصي
            </Button>

            {/* My Patients Button - Only for Doctors */}
            {isDoctor && (
              <Button
                onClick={onViewPatients}
                className="w-full h-12 rounded-xl mt-3 bg-gradient-to-r from-[#2196F3] to-[#1565C0] text-white hover:opacity-90"
              >
                <Users className="w-5 h-5 mr-2" />
                مرضاي
              </Button>
            )}

            {/* Request to Join Doctor - Only for Parents */}
            {!isDoctor && (
              <Button
                onClick={onPatientRequest}
                className="w-full h-12 rounded-xl mt-3 bg-gradient-to-r from-[#2196F3] to-[#1565C0] text-white hover:opacity-90"
              >
                <UserPlus className="w-5 h-5 mr-2" />
                طلب انضمام لطبيب
              </Button>
            )}
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-4 py-4 border-t border-b border-[#E3F2FD]">
            <button onClick={onViewFollowers} className="text-center hover:bg-[#E3F2FD] rounded-xl py-2 transition-colors">
              <p className="text-2xl text-[#1a1f36] mb-1">{isDoctor ? "2.5K" : "1.2K"}</p>
              <p className="text-sm text-[#64748b]">المتابعون</p>
            </button>
            <button onClick={onViewFollowing} className="text-center hover:bg-[#E3F2FD] rounded-xl py-2 transition-colors">
              <p className="text-2xl text-[#1a1f36] mb-1">{isDoctor ? "523" : "345"}</p>
              <p className="text-sm text-[#64748b]">المتابَعون</p>
            </button>
          </div>
        </Card>
      </div>

      {/* Posts Section */}
      <div className="px-6">
        <h3 className="text-xl text-[#1a1f36] mb-4 text-right">منشوراتي</h3>
        <div className="space-y-4">
          {userPosts.map((post) => (
            <Card key={post.id} className="p-5 rounded-2xl shadow-sm border-[#E3F2FD]">
              <p className="text-[#1a1f36] mb-4 text-right">{post.content}</p>
              <div className="flex items-center gap-6 pt-3 border-t border-[#E3F2FD]">
                <button className="flex items-center gap-2 text-[#64748b] hover:text-[#ec4899] transition-colors">
                  <Heart className="w-5 h-5" />
                  <span>{post.likes}</span>
                </button>
                <button 
                  onClick={() => onViewComments?.(post.id, isDoctor ? "د. سارة جونسون" : "إيميلي باركر", post.content)}
                  className="flex items-center gap-2 text-[#64748b] hover:text-[#2196F3] transition-colors"
                >
                  <MessageCircle className="w-5 h-5" />
                  <span>{post.comments}</span>
                </button>
                <span className="text-sm text-[#64748b] mr-auto">{post.timestamp}</span>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}