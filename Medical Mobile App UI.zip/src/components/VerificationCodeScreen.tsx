import { ArrowLeft } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { useState } from "react";

interface VerificationCodeScreenProps {
  onBack: () => void;
  onVerify: () => void;
  email: string;
}

export default function VerificationCodeScreen({ onBack, onVerify, email }: VerificationCodeScreenProps) {
  const [code, setCode] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (code.length !== 6) {
      setError("الرجاء إدخال رمز مكون من 6 أرقام");
      return;
    }
    
    setIsSubmitting(true);
    setError("");
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      // In a real app, verify the code here
      // For demo, accept any 6-digit code
      onVerify();
    }, 1000);
  };

  const handleResendCode = () => {
    // In a real app, resend the code
    alert("تم إرسال الرمز مرة أخرى");
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-[#E3F2FD] to-white flex flex-col" dir="rtl">
      {/* Header */}
      <div className="px-6 pt-12 pb-8">
        <button onClick={onBack} className="text-[#2196F3] mb-6">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-3xl text-[#1a1f36] mb-2 text-right">رمز التحقق</h1>
        <p className="text-[#64748b] text-right">
          أدخل الرمز المرسل إلى {email}
        </p>
      </div>

      {/* Form */}
      <div className="flex-1 px-6">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="code" className="mb-3 block text-[#1a1f36] text-right text-lg">
              رمز التحقق
            </Label>
            <Input
              id="code"
              type="text"
              value={code}
              onChange={(e) => {
                const value = e.target.value.replace(/\D/g, "");
                if (value.length <= 6) {
                  setCode(value);
                  setError("");
                }
              }}
              maxLength={6}
              placeholder="000000"
              className="h-16 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-center text-3xl tracking-[0.5em] font-mono"
              required
            />
            <p className="text-sm text-[#64748b] mt-2 text-center">
              {code.length}/6 أرقام
            </p>
            {error && (
              <p className="text-sm text-red-500 mt-2 text-center">{error}</p>
            )}
          </div>

          <Button
            type="submit"
            disabled={code.length !== 6 || isSubmitting}
            className="w-full h-14 rounded-2xl bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90 disabled:opacity-50"
          >
            {isSubmitting ? (
              <span className="flex items-center gap-2">
                <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                جاري التحقق...
              </span>
            ) : (
              "تحقق"
            )}
          </Button>

          {/* Resend Code */}
          <div className="text-center">
            <p className="text-sm text-[#64748b] mb-2">
              لم تستلم الرمز؟
            </p>
            <button
              type="button"
              onClick={handleResendCode}
              className="text-sm text-[#2196F3] hover:underline"
            >
              إعادة إرسال الرمز
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
