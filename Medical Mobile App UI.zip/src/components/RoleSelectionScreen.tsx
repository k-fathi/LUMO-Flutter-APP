import { User, Stethoscope } from "lucide-react";
import lumoLogo from "figma:asset/e038b1af61c3f07a311d9a957a2f820843644e3c.png";

interface RoleSelectionScreenProps {
  onSelectRole: (role: "parent" | "doctor") => void;
}

export default function RoleSelectionScreen({ onSelectRole }: RoleSelectionScreenProps) {
  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-[#2196F3] to-[#1565C0] flex flex-col items-center justify-center px-6 py-12" dir="rtl">
      {/* LUMO Robot Image */}
      <div className="mb-10 w-full max-w-sm px-8">
        <img 
          src={lumoLogo}
          alt="LUMO" 
          className="w-full h-auto object-contain"
        />
      </div>

      {/* Welcome Text */}
      <div className="text-center mb-12">
        <h1 className="text-4xl text-white mb-3">مرحباً بك في لومو</h1>
        <p className="text-white/90 text-lg">يرجى اختيار دورك للمتابعة</p>
      </div>

      {/* Role Selection Buttons */}
      <div className="w-full max-w-sm space-y-4 mb-12">
        <button
          onClick={() => onSelectRole("parent")}
          className="w-full h-14 bg-white rounded-2xl flex items-center justify-center gap-3 shadow-lg hover:shadow-xl transition-shadow"
        >
          <User className="w-5 h-5 text-[#2196F3]" />
          <span className="text-[#1a1a2e]">أنا مستخدم</span>
        </button>

        <button
          onClick={() => onSelectRole("doctor")}
          className="w-full h-14 bg-white rounded-2xl flex items-center justify-center gap-3 shadow-lg hover:shadow-xl transition-shadow"
        >
          <Stethoscope className="w-5 h-5 text-[#2196F3]" />
          <span className="text-[#1a1a2e]">أنا طبيب</span>
        </button>
      </div>

      {/* Footer Text */}
      <p className="text-white/60 text-center">صحتك، أولويتنا.</p>
    </div>
  );
}