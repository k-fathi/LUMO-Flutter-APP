import { ArrowLeft, Image as ImageIcon, Send } from "lucide-react";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";

interface CreatePostScreenProps {
  onBack: () => void;
  onPublish: () => void;
}

export default function CreatePostScreen({ onBack, onPublish }: CreatePostScreenProps) {
  return (
    <div className="min-h-screen w-full bg-white flex flex-col" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 bg-gradient-to-r from-[#2196F3] to-[#1565C0] px-6 py-4 flex items-center justify-between shadow-md z-10">
        <button onClick={onBack} className="text-white">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl text-white">إنشاء منشور</h1>
        <Button
          onClick={onPublish}
          className="bg-white text-[#2196F3] hover:bg-white/90 h-9 px-4 rounded-xl"
        >
          نشر
        </Button>
      </div>

      {/* Content */}
      <div className="flex-1 px-6 py-6">
        {/* User Info */}
        <div className="flex items-center gap-3 mb-6 flex-row-reverse justify-end">
          <div className="text-right">
            <h3 className="text-[#1a1a2e]">أحمد محمد</h3>
            <p className="text-sm text-[#64748b]">مستخدم</p>
          </div>
          <Avatar className="w-12 h-12">
            <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=profile" />
            <AvatarFallback>أم</AvatarFallback>
          </Avatar>
        </div>

        {/* Post Input */}
        <div className="space-y-4">
          <Textarea
            placeholder="بماذا تفكر؟"
            className="min-h-[200px] border-[#E3F2FD] bg-[#E3F2FD] focus:border-[#2196F3] focus:ring-[#2196F3] rounded-2xl p-4 resize-none text-right"
          />

          {/* Media Options */}
          <div className="flex items-center gap-4 pt-4 border-t border-[#E3F2FD]">
            <button className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#E3F2FD] text-[#2196F3] hover:bg-[#BBDEFB] transition-colors">
              <ImageIcon className="w-5 h-5" />
              <span>إضافة صورة</span>
            </button>
          </div>
        </div>

        {/* Guidelines */}
        <div className="mt-8 p-4 bg-[#E3F2FD] rounded-2xl">
          <h4 className="text-[#1565C0] mb-2 text-right">إرشادات المجتمع</h4>
          <ul className="text-sm text-[#64748b] space-y-1 text-right">
            <li>• كن محترماً وداعماً</li>
            <li>• شارك معلومات صحية مفيدة</li>
            <li>• احمِ الخصوصية - لا تفاصيل طبية شخصية</li>
            <li>• استشر المتخصصين للحصول على المشورة الطبية</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
