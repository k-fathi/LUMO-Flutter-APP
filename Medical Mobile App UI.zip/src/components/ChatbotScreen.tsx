import { Send } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import chatbotBg from "figma:asset/a692df3ebc4148c1d08c2ebe2e57fab3e4843c08.png";

export default function ChatbotScreen() {
  return (
    <div className="min-h-screen w-full flex flex-col relative overflow-hidden bg-white" dir="rtl">
      {/* Header */}
      <div className="relative bg-white border-b border-[#E3F2FD] px-6 py-4 flex items-center justify-center">
        <h2 className="text-[#1565C0]">المساعد الطبي الذكي</h2>
      </div>

      {/* Main Content with Robot Image - with background */}
      <div 
        className="relative flex-1 flex items-center justify-center px-6 py-12"
        style={{
          backgroundImage: `url(${chatbotBg})`,
          backgroundSize: 'contain',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      >
      </div>

      {/* Input Area */}
      <div className="relative bg-white px-6 py-6 pb-28">
        <div className="flex items-center gap-3">
          <Input
            placeholder="اسأل عن أي شيء"
            className="flex-1 h-12 rounded-full border-[#E3F2FD] bg-[#E3F2FD] focus:border-[#2196F3] focus:ring-[#2196F3] px-5 text-right"
          />
          <Button
            size="icon"
            className="w-12 h-12 rounded-full bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90 shadow-lg"
          >
            <Send className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}