import { ChevronRight } from "lucide-react";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface OnboardingScreenProps {
  step: number;
  onNext: () => void;
  onSkip: () => void;
}

const onboardingData = [
  {
    image: "https://images.unsplash.com/photo-1730817403237-c125215eb931?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoZWFsdGglMjB0cmFja2luZyUyMG1vYmlsZXxlbnwxfHx8fDE3NjAxNzExNzd8MA&ixlib=rb-4.1.0&q=80&w=1080",
    title: "تتبع صحتك",
    subtitle: "راقب مؤشراتك الصحية وابقَ على اطلاع دائم برحلة صحتك مع التتبع والرؤى في الوقت الفعلي.",
  },
  {
    image: "https://images.unsplash.com/photo-1758202292826-c40e172eed1c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZWRpY2FsJTIwdGVjaG5vbG9neSUyMEFJfGVufDF8fHx8MTc2MDE1NzU5OHww&ixlib=rb-4.1.0&q=80&w=1080",
    title: "استشارات طبية بالذكاء الاصطناعي",
    subtitle: "احصل على إرشادات طبية فورية من روبوت الدردشة المدعوم بالذكاء الاصطناعي، متاح على مدار الساعة للإجابة على أسئلتك الصحية.",
  },
  {
    image: "https://images.unsplash.com/photo-1758691462568-252f83aae3c8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N0b3IlMjBwYXRpZW50JTIwY29ubmVjdGlvbnxlbnwxfHx8fDE3NjAxNzExNzh8MA&ixlib=rb-4.1.0&q=80&w=1080",
    title: "تواصل مع الأطباء",
    subtitle: "ابنِ علاقات هادفة مع المتخصصين في الرعاية الصحية واحصل على الرعاية الشخصية عندما تحتاج إليها.",
  },
];

export default function OnboardingScreen({ step, onNext, onSkip }: OnboardingScreenProps) {
  const data = onboardingData[step];
  const isLastStep = step === onboardingData.length - 1;

  return (
    <div className="min-h-screen w-full bg-white flex flex-col" dir="rtl">
      {/* Skip Button */}
      <div className="flex justify-start p-6">
        <button
          onClick={onSkip}
          className="text-[#64748b] px-4 py-2 rounded-lg hover:bg-[#E3F2FD] transition-colors"
        >
          تخطي
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 pb-12">
        {/* Image */}
        <div className="w-full max-w-sm aspect-square mb-12 rounded-3xl overflow-hidden shadow-lg">
          <ImageWithFallback
            src={data.image}
            alt={data.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Text Content */}
        <div className="text-center mb-12 max-w-md">
          <h2 className="text-2xl text-[#1a1a2e] mb-4">{data.title}</h2>
          <p className="text-[#64748b]">{data.subtitle}</p>
        </div>

        {/* Dots Indicator */}
        <div className="flex gap-2 mb-12">
          {onboardingData.map((_, index) => (
            <div
              key={index}
              className={`h-2 rounded-full transition-all ${
                index === step
                  ? "w-8 bg-[#2196F3]"
                  : "w-2 bg-[#cbd5e1]"
              }`}
            />
          ))}
        </div>

        {/* Next Button */}
        <Button
          onClick={onNext}
          className="w-full max-w-sm h-14 rounded-2xl bg-[#2196F3] hover:bg-[#1565C0] text-white shadow-lg"
        >
          {isLastStep ? "ابدأ الآن" : "التالي"}
          <ChevronRight className="mr-2 w-5 h-5" />
        </Button>
      </div>
    </div>
  );
}
