import { useState } from "react";
import { UserCircle, Stethoscope, Baby, Mail, Lock, User, CreditCard, MapPin, Calendar, Phone } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";

interface SignUpScreenProps {
  role: "doctor" | "parent";
  onSignUp: () => void;
  onSignInClick: () => void;
}

export default function SignUpScreen({ role, onSignUp, onSignInClick }: SignUpScreenProps) {

  const isDoctor = role === "doctor";

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-[#E3F2FD] to-white overflow-auto" dir="rtl">
      <div className="max-w-md mx-auto px-6 py-12">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="w-20 h-20 bg-gradient-to-br from-[#2196F3] to-[#1565C0] rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-lg">
            {isDoctor ? (
              <Stethoscope className="w-10 h-10 text-white" />
            ) : (
              <Baby className="w-10 h-10 text-white" />
            )}
          </div>
          <h1 className="text-3xl text-[#1a1a2e] mb-2">إنشاء حساب</h1>
          <p className="text-[#64748b]">
            التسجيل ك{isDoctor ? "طبيب" : "مستخدم"}
          </p>
        </div>

        {/* Form */}
        <div className="space-y-5 mb-8">
          <div>
            <Label htmlFor="name" className="mb-2 block text-[#1a1a2e] text-right">الاسم الكامل</Label>
            <div className="relative">
              <User className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="name"
                type="text"
                placeholder="أدخل اسمك الكامل"
                className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="email" className="mb-2 block text-[#1a1a2e] text-right">البريد الإلكتروني</Label>
            <div className="relative">
              <Mail className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="email"
                type="email"
                placeholder="أدخل بريدك الإلكتروني"
                className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="mobile" className="mb-2 block text-[#1a1a2e] text-right">رقم الجوال</Label>
            <div className="relative">
              <Phone className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="mobile"
                type="tel"
                placeholder="أدخل رقم الجوال"
                className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="password" className="mb-2 block text-[#1a1a2e] text-right">كلمة المرور</Label>
            <div className="relative">
              <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="password"
                type="password"
                placeholder="أنشئ كلمة مرور"
                className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="confirmPassword" className="mb-2 block text-[#1a1a2e] text-right">تأكيد كلمة المرور</Label>
            <div className="relative">
              <Lock className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
              <Input
                id="confirmPassword"
                type="password"
                placeholder="أكد كلمة المرور"
                className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
              />
            </div>
          </div>

          {isDoctor && (
            <>
              <div>
                <Label htmlFor="doctorId" className="mb-2 block text-[#1a1a2e] text-right">رقم الطبيب</Label>
                <div className="relative">
                  <CreditCard className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                  <Input
                    id="doctorId"
                    type="text"
                    placeholder="أدخل رقم الطبيب"
                    className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="clinicLocation" className="mb-2 block text-[#1a1a2e] text-right">موقع العيادة</Label>
                <div className="relative">
                  <MapPin className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                  <Input
                    id="clinicLocation"
                    type="text"
                    placeholder="أدخل موقع العيادة"
                    className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
                  />
                </div>
              </div>
            </>
          )}

          {!isDoctor && (
            <>
              <div>
                <Label htmlFor="childInfo" className="mb-2 block text-[#1a1a2e] text-right">اسم الطفل</Label>
                <div className="relative">
                  <Baby className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                  <Input
                    id="childInfo"
                    type="text"
                    placeholder="أدخل اسم الطفل"
                    className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="childAge" className="mb-2 block text-[#1a1a2e] text-right">عمر الطفل</Label>
                <div className="relative">
                  <Calendar className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                  <Input
                    id="childAge"
                    type="number"
                    placeholder="أدخل عمر الطفل"
                    className="pr-12 h-14 rounded-2xl border-[#E3F2FD] bg-white focus:border-[#2196F3] focus:ring-[#2196F3] text-right"
                  />
                </div>
              </div>
            </>
          )}
        </div>

        {/* Create Account Button */}
        <Button
          onClick={onSignUp}
          className="w-full h-14 rounded-2xl bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90 text-white shadow-lg mb-6"
        >
          إنشاء حساب
        </Button>

        {/* Sign In Link */}
        <p className="text-center text-[#64748b]">
          لديك حساب بالفعل؟{" "}
          <button onClick={onSignInClick} className="text-[#2196F3]">
            تسجيل الدخول
          </button>
        </p>
      </div>
    </div>
  );
}
