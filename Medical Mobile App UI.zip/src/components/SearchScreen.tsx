import { ArrowLeft, Search } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";

interface SearchScreenProps {
  onBack: () => void;
}

const users = [
  {
    id: 1,
    name: "د. محمد أحمد",
    role: "طبيب قلب",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=doctor1",
    followers: "2.5K",
  },
  {
    id: 2,
    name: "سارة علي",
    role: "مستخدم",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=parent1",
    followers: "1.2K",
  },
  {
    id: 3,
    name: "د. فاطمة حسن",
    role: "طبيبة أطفال",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=doctor2",
    followers: "3.1K",
  },
  {
    id: 4,
    name: "أحمد محمود",
    role: "مستخدم",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=parent2",
    followers: "890",
  },
  {
    id: 5,
    name: "د. يوسف خالد",
    role: "طبيب عام",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=doctor3",
    followers: "1.8K",
  },
];

export default function SearchScreen({ onBack }: SearchScreenProps) {
  return (
    <div className="min-h-screen w-full bg-white" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 bg-gradient-to-r from-[#2196F3] to-[#1565C0] px-6 py-4 shadow-md z-10">
        <div className="flex items-center gap-4 mb-4">
          <button onClick={onBack} className="text-white">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-xl text-white">البحث</h1>
        </div>
        
        {/* Search Input */}
        <div className="relative">
          <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
          <Input
            placeholder="ابحث عن مستخدمين..."
            className="pr-12 h-12 rounded-full border-0 bg-white focus:ring-2 focus:ring-white/20 text-right"
          />
        </div>
      </div>

      {/* Results */}
      <div className="px-6 py-6">
        <h3 className="text-[#64748b] mb-4 text-right">النتائج</h3>
        <div className="space-y-3">
          {users.map((user) => (
            <Card key={user.id} className="p-4 rounded-2xl shadow-sm border-[#E3F2FD] hover:shadow-md transition-shadow">
              <div className="flex items-center gap-4">
                <Avatar className="w-14 h-14">
                  <AvatarImage src={user.avatar} />
                  <AvatarFallback>{user.name[0]}</AvatarFallback>
                </Avatar>
                <div className="flex-1 text-right">
                  <h4 className="text-[#1a1a2e] mb-1">{user.name}</h4>
                  <p className="text-sm text-[#64748b]">{user.followers} متابع</p>
                </div>
                <Button
                  size="sm"
                  className="h-9 px-4 rounded-xl bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90 text-white"
                >
                  متابعة
                </Button>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
