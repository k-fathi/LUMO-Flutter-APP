import { Search, MessageSquare, Plus } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Input } from "./ui/input";
import { Button } from "./ui/button";

interface Chat {
  id: number;
  name: string;
  avatar: string;
  lastMessage: string;
  time: string;
  unread: number;
  isOnline: boolean;
}

interface ChatListScreenProps {
  onChatClick: (chatId: number) => void;
  onNewChat?: () => void;
}

const recentChats: Chat[] = [
  {
    id: 1,
    name: "د. سارة أحمد",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=doctor",
    lastMessage: "لا توجد قيود محددة، لكنني أوصي بالحفاظ على نظام غذائي متوازن",
    time: "10:36 صباحاً",
    unread: 0,
    isOnline: true,
  },
  {
    id: 2,
    name: "د. محمد خالد",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=doctor2",
    lastMessage: "سأحتاج لرؤية النتائج الجديدة في أقرب وقت ممكن",
    time: "أمس",
    unread: 2,
    isOnline: false,
  },
  {
    id: 3,
    name: "د. ليلى حسن",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=doctor3",
    lastMessage: "شكراً على المتابعة. الأمور تسير بشكل جيد",
    time: "أمس",
    unread: 0,
    isOnline: false,
  },
  {
    id: 4,
    name: "د. عمر السيد",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=doctor4",
    lastMessage: "موعد الغد في الساعة 3 مساءً",
    time: "2024/10/19",
    unread: 1,
    isOnline: false,
  },
  {
    id: 5,
    name: "د. نور الدين",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=doctor5",
    lastMessage: "تم استلام التقرير الطبي",
    time: "2024/10/18",
    unread: 0,
    isOnline: true,
  },
];

export default function ChatListScreen({ onChatClick, onNewChat }: ChatListScreenProps) {
  return (
    <div className="min-h-screen w-full bg-[#E3F2FD]" dir="rtl">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#2196F3] to-[#1565C0] px-6 py-6 shadow-lg">
        <h1 className="text-white text-2xl mb-4">الدردشة</h1>
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#64748b]" />
          <Input
            placeholder="ابحث عن محادثة..."
            className="w-full h-12 pr-12 rounded-full border-none bg-white text-right shadow-md focus:ring-2 focus:ring-white/50"
          />
        </div>
      </div>

      {/* Chat List */}
      <div className="bg-white mt-2 pb-32">
        {recentChats.length > 0 ? (
          recentChats.map((chat) => (
            <button
              key={chat.id}
              onClick={() => onChatClick(chat.id)}
              className="w-full px-6 py-4 flex items-center gap-4 border-b border-[#E3F2FD] hover:bg-[#E3F2FD]/30 transition-colors"
            >
              {/* Avatar with online indicator */}
              <div className="relative">
                <Avatar className="w-14 h-14 border-2 border-[#2196F3]">
                  <AvatarImage src={chat.avatar} />
                  <AvatarFallback className="bg-gradient-to-r from-[#2196F3] to-[#1565C0] text-white">
                    {chat.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                {chat.isOnline && (
                  <div className="absolute bottom-0 right-0 w-4 h-4 bg-[#22c55e] border-2 border-white rounded-full"></div>
                )}
              </div>

              {/* Chat Info */}
              <div className="flex-1 min-w-0 text-right">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-[#1565C0]">{chat.name}</p>
                  <span className="text-xs text-[#64748b]">{chat.time}</span>
                </div>
                <div className="flex items-center justify-between">
                  <p className="text-sm text-[#64748b] truncate ml-2">
                    {chat.lastMessage}
                  </p>
                  {chat.unread > 0 && (
                    <div className="flex-shrink-0 w-6 h-6 rounded-full bg-gradient-to-r from-[#2196F3] to-[#1565C0] flex items-center justify-center">
                      <span className="text-xs text-white">{chat.unread}</span>
                    </div>
                  )}
                </div>
              </div>
            </button>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-20 h-20 rounded-full bg-[#E3F2FD] flex items-center justify-center mb-4">
              <MessageSquare className="w-10 h-10 text-[#2196F3]" />
            </div>
            <p className="text-[#64748b] text-center">لا توجد محادثات بعد</p>
            <p className="text-[#64748b]/60 text-sm text-center mt-2">
              ابدأ محادثة جديدة مع الأطباء
            </p>
          </div>
        )}
      </div>

      {/* Floating New Chat Button */}
      {onNewChat && (
        <Button
          onClick={onNewChat}
          className="fixed bottom-24 left-6 w-14 h-14 rounded-full bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90 shadow-2xl z-20"
          size="icon"
        >
          <Plus className="w-6 h-6 text-white" />
        </Button>
      )}
    </div>
  );
}