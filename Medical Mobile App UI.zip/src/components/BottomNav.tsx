import { Home, Activity, MessageSquare, Bot, User, Users } from "lucide-react";

interface BottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  role?: "parent" | "doctor";
}

export default function BottomNav({ activeTab, onTabChange, role = "parent" }: BottomNavProps) {
  // For Parent: community, analysis, chat, chatbot, profile
  // For Doctor: community, mypatients, chat, chatbot, profile
  const tabs = role === "doctor" 
    ? [
        { id: "community", icon: Home, label: "الرئيسية" },
        { id: "mypatients", icon: Users, label: "مرضاي" },
        { id: "chat", icon: MessageSquare, label: "الدردشة" },
        { id: "chatbot", icon: Bot, label: "المساعد الذكي" },
        { id: "profile", icon: User, label: "الملف" },
      ]
    : [
        { id: "community", icon: Home, label: "الرئيسية" },
        { id: "analysis", icon: Activity, label: "التحليل" },
        { id: "chat", icon: MessageSquare, label: "الدردشة" },
        { id: "chatbot", icon: Bot, label: "المساعد الذكي" },
        { id: "profile", icon: User, label: "الملف" },
      ];

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-[#E3F2FD] shadow-lg z-50" dir="rtl">
      <div className="max-w-md mx-auto flex justify-around items-center px-2 py-3">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className="flex flex-col items-center gap-1 px-4 py-2 rounded-2xl transition-all"
            >
              <div
                className={`p-2 rounded-xl transition-all ${
                  isActive
                    ? "bg-gradient-to-r from-[#2196F3] to-[#1565C0] shadow-md"
                    : "bg-transparent"
                }`}
              >
                <Icon
                  className={`w-5 h-5 ${
                    isActive ? "text-white" : "text-[#64748b]"
                  }`}
                />
              </div>
              <span
                className={`text-xs ${
                  isActive ? "text-[#2196F3]" : "text-[#64748b]"
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
