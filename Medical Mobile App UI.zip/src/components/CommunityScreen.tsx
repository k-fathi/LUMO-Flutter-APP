import { Heart, MessageCircle, MoreHorizontal, Plus, Search } from "lucide-react";
import { Card } from "./ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Button } from "./ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { useState } from "react";

interface CommunityScreenProps {
  onCreatePost?: () => void;
  onEditPost?: (postId: number, content: string) => void;
  onDeletePost?: (postId: number) => void;
  onViewComments?: (postId: number, author: string, content: string) => void;
  onSearch?: () => void;
}

const posts = [
  {
    id: 1,
    author: "د. محمد أحمد",
    role: "طبيب قلب",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=michael",
    timestamp: "منذ ساعتين",
    content: "أخبار رائعة! تُظهر الأبحاث الجديدة أن ممارسة الرياضة القلبية المنتظمة يمكن أن تقلل بشكل كبير من خطر الإصابة بأمراض القلب. تذكر، حتى 30 دقيقة من المشي اليومي يمكن أن تحدث فرقاً كبيراً. 💙",
    likes: 142,
    comments: 23,
  },
  {
    id: 2,
    author: "سارة أحمد",
    role: "مستخدم",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=sarah",
    timestamp: "منذ 5 ساعات",
    content: "أردت فقط مشاركة تجربتي مع عيادة الأطفال الجديدة في وسط المدينة. كان الموظفون رائعين ومتفهمين جداً مع ابنتي. أوصي به بشدة للآباء الآخرين! 🏥",
    likes: 89,
    comments: 15,
  },
  {
    id: 3,
    author: "د. فاطمة علي",
    role: "طبيبة أطفال",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=emily",
    timestamp: "منذ يوم",
    content: "تذكير: موسم الإنفلونزا يقترب! الآن هو الوقت المثالي لجدولة لقاحات الإنفلونزا لعائلتك. الوقاية دائماً أفضل من العلاج. ابقوا بصحة جيدة! 💉",
    likes: 256,
    comments: 42,
  },
  {
    id: 4,
    author: "يوسف محمود",
    role: "مستخدم",
    avatar: "https://api.dicebear.com/7.x/avataaars/svg?seed=james",
    timestamp: "منذ يومين",
    content: "أبحث عن نصائح حول إدارة حساسية الطعام لدى ابني. هل هناك آباء يتعاملون مع تحديات مماثلة؟ أود التواصل وتبادل الخبرات.",
    likes: 34,
    comments: 18,
  },
];

export default function CommunityScreen({ 
  onCreatePost, 
  onEditPost, 
  onDeletePost, 
  onViewComments,
  onSearch 
}: CommunityScreenProps) {
  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-[#E3F2FD] to-white pb-24" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 bg-white border-b border-[#E3F2FD] px-6 py-4 z-10 shadow-sm">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl text-[#1565C0]">المجتمع</h1>
          <Button
            onClick={onSearch}
            size="icon"
            className="w-10 h-10 rounded-full bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90 text-white"
          >
            <Search className="w-5 h-5" />
          </Button>
        </div>
      </div>

      {/* Create Post Quick Access */}
      <div className="px-4 pt-4">
        <Card 
          onClick={onCreatePost}
          className="p-4 rounded-2xl shadow-sm border-[#E3F2FD] bg-white cursor-pointer hover:shadow-md transition-shadow"
        >
          <div className="flex items-center gap-3">
            <Avatar className="w-10 h-10">
              <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=profile" />
              <AvatarFallback>أن</AvatarFallback>
            </Avatar>
            <div className="flex-1 h-10 bg-[#E3F2FD] rounded-full flex items-center px-4 text-[#64748b] text-right">
              بماذا تفكر؟
            </div>
            <Button
              size="icon"
              className="w-10 h-10 rounded-full bg-gradient-to-r from-[#2196F3] to-[#1565C0]"
            >
              <Plus className="w-5 h-5" />
            </Button>
          </div>
        </Card>
      </div>

      {/* Posts Feed */}
      <div className="px-4 py-4 space-y-4">
        {posts.map((post) => (
          <Card key={post.id} className="p-5 rounded-3xl shadow-md border-0 bg-white">
            {/* Post Header */}
            <div className="flex items-start gap-3 mb-4 flex-row-reverse">
              <Avatar className="w-12 h-12">
                <AvatarImage src={post.avatar} />
                <AvatarFallback>{post.author[0]}</AvatarFallback>
              </Avatar>
              <div className="flex-1 text-right">
                <h3 className="text-[#1a1a2e]">{post.author}</h3>
                <p className="text-sm text-[#64748b]">{post.role} • {post.timestamp}</p>
              </div>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="text-[#64748b] hover:text-[#2196F3]">
                    <MoreHorizontal className="w-5 h-5" />
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-40" dir="rtl">
                  <DropdownMenuItem
                    onClick={() => onEditPost?.(post.id, post.content)}
                    className="cursor-pointer"
                  >
                    تعديل المنشور
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={() => onDeletePost?.(post.id)}
                    className="cursor-pointer text-[#ef4444]"
                  >
                    حذف المنشور
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* Post Content */}
            <p className="text-[#1a1a2e] mb-4 leading-relaxed text-right">{post.content}</p>

            {/* Post Actions */}
            <div className="flex items-center gap-6 pt-3 border-t border-[#E3F2FD]">
              <button className="flex items-center gap-2 text-[#64748b] hover:text-[#ec4899] transition-colors">
                <Heart className="w-5 h-5" />
                <span>{post.likes}</span>
              </button>
              <button 
                onClick={() => onViewComments?.(post.id, post.author, post.content)}
                className="flex items-center gap-2 text-[#64748b] hover:text-[#2196F3] transition-colors"
              >
                <MessageCircle className="w-5 h-5" />
                <span>{post.comments}</span>
              </button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
