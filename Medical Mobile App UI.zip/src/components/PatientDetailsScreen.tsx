import { ArrowLeft, User, Calendar, ChevronRight, Circle } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Card } from "./ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer } from "recharts";

interface PatientDetailsScreenProps {
  onBack: () => void;
  patientName: string;
  patientAge: number;
  patientAvatar: string;
}

const analysisData = [
  {
    date: "22/05/01 - 12:03",
    title: "الألغاز",
    emotions: [
      { name: "محايد", value: 56, color: "#2196F3" },
      { name: "حزين", value: 20, color: "#ec4899" },
    ],
    results: [
      { label: "محايد", checked: true },
      { label: "حزين", checked: true },
      { label: "خائف", checked: false },
      { label: "غاضب", checked: false },
      { label: "سعيد", checked: false },
    ],
  },
  {
    date: "22/05/01 - 12:03",
    title: "الألغاز",
    emotions: [
      { name: "محايد", value: 100, color: "#2196F3" },
    ],
    results: [
      { label: "محايد", checked: true },
      { label: "حزين", checked: false },
      { label: "خائف", checked: false },
      { label: "غاضب", checked: false },
      { label: "سعيد", checked: false },
    ],
  },
  {
    date: "22/05/01 - 12:03",
    title: "الألغاز",
    emotions: [
      { name: "محايد", value: 56, color: "#2196F3" },
      { name: "حزين", value: 20, color: "#ec4899" },
    ],
    results: [
      { label: "محايد", checked: true },
      { label: "حزين", checked: true },
      { label: "خائف", checked: false },
      { label: "غاضب", checked: false },
      { label: "سعيد", checked: false },
    ],
  },
];

export default function PatientDetailsScreen({ 
  onBack, 
  patientName, 
  patientAge, 
  patientAvatar 
}: PatientDetailsScreenProps) {
  return (
    <div className="min-h-screen w-full bg-white pb-24" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 bg-gradient-to-r from-[#2196F3] to-[#1565C0] px-6 py-4 flex items-center justify-between shadow-md z-10">
        <button onClick={onBack} className="text-white">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl text-white">تفاصيل المريض</h1>
        <div className="w-6" /> {/* Spacer for centering */}
      </div>

      {/* Patient Info Card */}
      <div className="px-6 py-6">
        <Card className="p-6 rounded-2xl shadow-md border-[#E3F2FD] bg-gradient-to-br from-[#E3F2FD] to-white">
          <div className="flex items-center gap-4">
            <Avatar className="w-20 h-20 border-4 border-white">
              <AvatarImage src={patientAvatar} />
              <AvatarFallback>{patientName[0]}</AvatarFallback>
            </Avatar>
            <div className="flex-1 text-right">
              <div className="flex items-center gap-2 mb-2 flex-row-reverse justify-end">
                <h2 className="text-2xl text-[#1565C0]">{patientName}</h2>
                <User className="w-5 h-5 text-[#2196F3]" />
              </div>
              <div className="flex items-center gap-2 flex-row-reverse justify-end">
                <p className="text-[#64748b]">{patientAge} سنوات</p>
                <Calendar className="w-4 h-4 text-[#64748b]" />
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Analysis Section Header */}
      <div className="px-6 py-2">
        <div className="flex items-center justify-between">
          <h2 className="text-xl text-[#1565C0]">التحليل</h2>
          <button className="text-[#2196F3]">
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Analysis Cards */}
      <div className="px-6 py-4 space-y-6">
        {analysisData.map((item, index) => (
          <Card key={index} className="p-6 rounded-3xl shadow-md border-[#E3F2FD]">
            {/* Date */}
            <p className="text-sm text-[#2196F3] mb-3 text-right">التاريخ: {item.date}</p>

            {/* Title */}
            <h3 className="text-xl text-[#1565C0] mb-6 text-right">{item.title}</h3>

            <div className="flex items-start gap-6">
              {/* Chart */}
              <div className="flex-shrink-0">
                <div className="w-28 h-28 relative">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={item.emotions}
                        cx="50%"
                        cy="50%"
                        innerRadius={30}
                        outerRadius={50}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {item.emotions.map((entry, idx) => (
                          <Cell key={`cell-${idx}`} fill={entry.color} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-sm text-[#64748b]">
                      {item.emotions[0].value}
                    </span>
                  </div>
                </div>
              </div>

              {/* Results */}
              <div className="flex-1 space-y-2">
                {item.results.map((result, idx) => (
                  <div key={idx} className="flex items-center gap-3 flex-row-reverse justify-end">
                    <span className="text-[#64748b]">{result.label}</span>
                    <Circle
                      className={`w-4 h-4 ${
                        result.checked
                          ? "fill-[#ec4899] text-[#ec4899]"
                          : "text-[#cbd5e1]"
                      }`}
                    />
                  </div>
                ))}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
