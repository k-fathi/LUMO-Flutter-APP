import { ArrowLeft, Send } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card } from "./ui/card";
import { useState } from "react";

interface PatientRequestScreenProps {
  onBack: () => void;
  onRequestSent?: () => void;
}

export default function PatientRequestScreen({ onBack, onRequestSent }: PatientRequestScreenProps) {
  const [code, setCode] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = () => {
    if (code.length !== 6) return;
    
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      
      // Reset after showing success message
      setTimeout(() => {
        onRequestSent?.();
      }, 2000);
    }, 1000);
  };

  return (
    <div className="min-h-screen w-full bg-white" dir="rtl">
      {/* Header */}
      <div className="sticky top-0 bg-gradient-to-r from-[#2196F3] to-[#1565C0] px-6 py-4 flex items-center gap-4 shadow-md z-10">
        <button onClick={onBack} className="text-white">
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl text-white">طلب انضمام للطبيب</h1>
      </div>

      {/* Content */}
      <div className="px-6 py-8">
        {!isSuccess ? (
          <>
            {/* Instruction Card */}
            <Card className="p-6 rounded-2xl bg-gradient-to-br from-[#E3F2FD] to-[#BBDEFB]/50 border-0 mb-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-md">
                  <Send className="w-8 h-8 text-[#2196F3]" />
                </div>
                <h2 className="text-xl text-[#1a1f36] mb-2">أدخل كود الطبيب</h2>
                <p className="text-sm text-[#64748b]">
                  احصل على الكود من طبيبك لإرسال طلب الانضمام إلى قائمة مرضاه
                </p>
              </div>
            </Card>

            {/* Code Input Form */}
            <div className="space-y-6">
              <div>
                <Label htmlFor="code" className="mb-3 block text-[#1a1f36] text-right text-lg">
                  كود الطبيب
                </Label>
                <Input
                  id="code"
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  maxLength={6}
                  placeholder="أدخل الكود المكون من 6 أحرف"
                  className="h-16 rounded-2xl border-[#E3F2FD] bg-[#E3F2FD] focus:border-[#2196F3] focus:ring-[#2196F3] text-center text-2xl tracking-[0.5em] font-mono"
                />
                <p className="text-sm text-[#64748b] mt-2 text-center">
                  {code.length}/6 أحرف
                </p>
              </div>

              {/* Submit Button */}
              <Button
                onClick={handleSubmit}
                disabled={code.length !== 6 || isSubmitting}
                className="w-full h-14 rounded-2xl bg-gradient-to-r from-[#2196F3] to-[#1565C0] hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed text-lg"
              >
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    <span className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    جاري الإرسال...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <Send className="w-5 h-5" />
                    إرسال الطلب
                  </span>
                )}
              </Button>
            </div>

            {/* Help Text */}
            <div className="mt-8 p-4 bg-[#E3F2FD] rounded-2xl">
              <h4 className="text-[#1565C0] mb-2 text-right">ملاحظة</h4>
              <ul className="text-sm text-[#64748b] space-y-1 text-right">
                <li>• اطلب الكود من طبيبك مباشرة</li>
                <li>• الكود صالح لمدة 24 ساعة فقط</li>
                <li>• سيتم إشعارك عند قبول الطبيب لطلبك</li>
              </ul>
            </div>
          </>
        ) : (
          /* Success Message */
          <Card className="p-8 rounded-2xl border-0 shadow-lg">
            <div className="text-center">
              <div className="w-20 h-20 bg-gradient-to-br from-[#2196F3] to-[#1565C0] rounded-full flex items-center justify-center mx-auto mb-4">
                <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <h2 className="text-2xl text-[#1a1f36] mb-2">تم إرسال الطلب بنجاح!</h2>
              <p className="text-[#64748b]">
                سيتم إشعارك عند مراجعة الطبيب لطلبك
              </p>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}
