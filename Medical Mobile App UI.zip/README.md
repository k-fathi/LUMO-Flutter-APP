
  # Medical Mobile App UI

  This is a code bundle for Medical Mobile App UI. The original project is available at https://www.figma.com/design/E2e2QzRJOKWTtppdCxmfrQ/Medical-Mobile-App-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  